# Automated Payment Reader + Discord Shop + Firebase (Android)

এই source project-এর আপডেটেড checkout flow-এ কোনো payment-admin command ব্যবহারকারীর দরকার নেই। Customer flow: **Shop-এ package নির্বাচন → bKash/Nagad নির্বাচন → ONLINE CHECK → নম্বর দেখানো (Reader online হলে) → TxnID submit → trusted Reader event match → account creation**। Payment panel bot startup-এ নিজে sync হয়।

## 1. Auto Coupon এবং অতিরিক্ত পেমেন্ট

- Auto Coupon default **ON**। Shop panel-এ `Auto Coupon ON/OFF` বোতাম ব্যবহারকারীভিত্তিক preference সংরক্ষণ করে (`user_settings/{DiscordUserId}/autoCouponEnabled`)।
- Auto Coupon ON থাকলে overpayment থেকে তৈরি ওই ব্যবহারকারীর active coupon পরের নতুন checkout-এ নিজে থেকে প্রয়োগ হবে।
- Auto Coupon OFF থাকলে package checkout-এ **Coupon Code ব্যবহার করুন** অপশন দেখাবে; ব্যবহারকারী চাইলে code manually দিতে পারবেন। Preference পরিবর্তনটি পরের নতুন checkout থেকে কার্যকর হয়।
- Package price-এর চেয়ে বেশি verified-reader amount জমা পড়লে পার্থক্যটুকু value-র coupon তৈরি হয় (90 দিনের মেয়াদ)।
- Coupon balance package price-এর চেয়ে বেশি হলে শুধু যতটুকু ছাড় দরকার ততটুকু consume হয়; অবশিষ্ট `remainingValue` রেখে coupon active থাকে। উদাহরণ: 500 BDT balance থেকে 300 BDT package-এ 300 ব্যবহার হলে 200 BDT বাকি থাকে।
- Coupon নিজের Discord user ID-এর সঙ্গে বাঁধা; অন্য কারও code জানলেও ব্যবহার করা যাবে না। একই সময়ে আরেক checkout-এ reserved coupon 30 মিনিট পরে stale হিসেবে reclaim করা যেতে পারে।

## 2. Android Reader: কোন notification পড়বে

- Google Play-এর official package ID exact match: Nagad `com.konasl.nagad` এবং bKash `com.bKash.customerapp`। Google Play listings: [Nagad](https://play.google.com/store/apps/details?id=com.konasl.nagad), [bKash](https://play.google.com/store/apps/details?id=com.bKash.customerapp)।
- SMS/Messages app notification থেকে কেবল notification **title/sender ID ঠিক `NAGAD` বা `BKASH`** হলে পড়বে। Numeric sender, অন্য নাম/নম্বর, অথবা text-এর মধ্যে শুধু “Nagad/bKash” শব্দ থাকলে বাদ যাবে। Android SMS app যদি official sender ID-কে title-এ না দেখায়, message ইচ্ছাকৃতভাবে ignore হবে।
- Reader notification-এর full message upload করে না; TxnID, provider, amount (যদি parse করা যায়), package ID এবং timestamps-এর মতো সীমিত metadata পাঠায়।
- Notice: sender title exact match হওয়া মানে official provider-এর backend থেকে transaction সত্য বলে cryptographic proof নয়। Production-grade নিশ্চিতকরণের জন্য approved bKash/Nagad Merchant API/webhook দরকার।

## 3. Offline mode: কোনো delayed auto-upload নয়

- Event upload করার আগে Android notification listener active, Firebase `.info/connected`, current online-session timestamp, এবং validated internet connection—সবগুলোই থাকতে হয়।
- Reader event Android Firebase SDK-এর queued `setValue/runTransaction` দিয়ে নয়, authenticated Realtime Database REST `PUT` দিয়ে পাঠায়। `if-match: null_etag` একই TxnID-এর পুরোনো record overwrite হতে দেয় না। Firebase REST conditional request-এর নথি: https://firebase.google.com/docs/reference/rest/database/ এবং https://firebase.google.com/docs/database/rest/save-data।
- Offline/disconnected অবস্থায় notification এলে বা upload চলার সময় connectivity হারালে event drop হবে, local retry queue-তে রাখা হবে না। পুনরায় online হলে নতুন online-session timestamp তৈরি হয়; তার আগের notification timestamp-এর event drop হবে। 2 মিনিটের বেশি পুরোনো notification-ও skip হয়। ফলে offline সময়ে পাঠানো টাকা এই Reader থেকে automatic matching হবে না—provider statement/API বা অন্য বৈধ যাচাই দরকার।
- Heartbeat প্রতি 60 সেকেন্ডে পাঠানোর চেষ্টা হয়। Bot-এর default online window 90 সেকেন্ড; stale heartbeat হলে number hide হয়। Android battery/background controls heartbeat বিলম্বিত করতে পারে, তাই safety-এর জন্য checkout কখনো offline Reader-কে online ধরে না।

## 4. Setup

### Firebase একবার configure

1. Firebase project-এ Realtime Database তৈরি করো এবং Authentication → Sign-in method → Anonymous চালু করো।
2. Android app register করো package name `com.example.paymentreader` দিয়ে এবং project-এর `google-services.json` ফাইলটি `mobile-reader/app/google-services.json`-এ রাখো।
3. `firebase/database.rules.fragment.json`-এর `reader_devices` এবং `reader_events` rules বর্তমান rules-এর সঙ্গে merge করো; পুরো rules file replace করবে না।
4. Android app build/install করে open করো, Firebase connect হলে **Copy trusted Reader UID** চাপো, তারপর Notification Access Settings-এ Payment Reader enable করো।

### Discord bot config

1. `discord-bot/.env.example` থেকে `.env` বানাও এবং `TOKEN`, `FIREBASE_DB_URL`, `FIREBASE_CONFIG` পূরণ করো। Firebase service-account JSON শুধু bot server-এ রাখবে, Android app-এর মধ্যে নয়।
2. Android UI থেকে কপি করা UID-টি `PAYMENT_READER_UIDS`-এ বসাও। এটি one-time trusted device allowlist, কোনো transaction data manual seed করা নয়।
3. `BKASH_PAYMENT_NUMBER` এবং `NAGAD_PAYMENT_NUMBER`-এ payment number বসাও। এগুলোও server environment-এর one-time config; Firebase-এ প্রতি purchase-এর জন্য number বসাতে হয় না।
4. `cd discord-bot && npm install && npm start` চালাও। Bot startup-এ `CHANNELS.PAYMENT_PANEL`-এ payment panel নিজে create/update করবে।

## 5. Customer-এর ব্যবহার

1. Shop panel-এ Auto Coupon ON/OFF setting প্রয়োজনমতো বদলাবে। ON default; OFF করলে coupon code manually দেওয়া যাবে।
2. Dropdown থেকে package বেছে নেবে। Auto Coupon ON থাকলে নিজের active coupon নিজে apply হবে এবং remaining balance দেখাবে।
3. bKash বা Nagad বেছে নেবে। Reader online ও configured number থাকলেই number দেখাবে; offline হলে `ONLINE CHECK` থাকবে এবং bট নিজে প্রতি 15 সেকেন্ডে সর্বোচ্চ 5 মিনিট status recheck করবে।
4. টাকা পাঠানোর পর পাওয়া TxnID submit করবে। Bot trusted Reader event-এর TxnID/provider/amount/time মিলিয়ে duplicate use আটকাবে।

## 6. Security / Testing notes

- Notification-based matching official provider API-এর সমান নিশ্চয়তা নয়। Provider-app package/sender allowlist ভুল message কমায়; তবু final payment truth-এর জন্য official API/webhook সর্বোত্তম।
- Reader app-এর Notification Access permission ব্যবহারকারীকে একবার enable করতে হয়।
- `firebase/database.rules.fragment.json` existing database rules-এর fragment, সম্পূর্ণ rules file নয়।
- `node --check discord-bot/index.js` দিয়ে JS syntax যাচাই করা যায়। এই পরিবেশে Android SDK/Gradle, নিজস্ব `google-services.json`, Discord token এবং Firebase service account নেই; তাই APK build বা live Discord/Firebase test সম্পন্ন বলে দাবি করা হচ্ছে না।
- Existing C++ application-এর plain-text password compatibility issue এই update-এ পরিবর্তন করা হয়নি; password hashing-এর জন্য C++ login flow ও data schema একসঙ্গে migrate করতে হবে।

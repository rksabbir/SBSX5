require("dotenv").config();
// ================================
// 🚀 PART 1 - Setup + Express + Firebase + Config
// ================================

const express = require("express");
const fs = require("fs");
const crypto = require("crypto");
const admin = require("firebase-admin"); // Firebase Admin SDK

const {
    Client,
    GatewayIntentBits,
    Partials,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    EmbedBuilder,
    ActivityType,
    StringSelectMenuBuilder,
    PermissionFlagsBits,
    MessageFlags,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle
} = require("discord.js");

// html-transcripts ইম্পোর্ট
const discordTranscripts = require("discord-html-transcripts");

// রেনডার Environment Variable থেকে অবজেক্ট লোড করার লজিক
let serviceAccount;
try {
    if (process.env.FIREBASE_CONFIG) {
        serviceAccount = JSON.parse(process.env.FIREBASE_CONFIG);
    } else {
        serviceAccount = require("./firebase-service-account.json");
    }
} catch (e) {
    console.error("❌ Firebase config load failed. Set FIREBASE_CONFIG or add firebase-service-account.json.", e.message);
    process.exit(1);
}

const firebaseURL = process.env.FIREBASE_DB_URL;
if (!serviceAccount || !firebaseURL || !/^https?:\/\//i.test(firebaseURL)) {
    console.error("❌ Firebase configuration is incomplete. FIREBASE_CONFIG (or firebase-service-account.json) and a valid FIREBASE_DB_URL are required.");
    process.exit(1);
}

// ফায়ারবেস ইনিশিয়ালাইজেশন
admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: firebaseURL
});
const db = admin.database();

// Only explicitly trusted Reader device UIDs can make checkout show a payment number.
// Set PAYMENT_READER_UIDS on the bot server to the UID displayed by the Android Reader app.
const TRUSTED_READER_UIDS = new Set(
    String(process.env.PAYMENT_READER_UIDS || "").split(",").map(value => value.trim()).filter(Boolean)
);
const READER_ONLINE_WINDOW_MS = Math.max(30_000, Number(process.env.READER_ONLINE_WINDOW_MS || 90_000));
const READER_RECHECK_COOLDOWN_MS = Math.max(10_000, Number(process.env.READER_RECHECK_COOLDOWN_MS || 15_000));
const READER_AUTO_WATCH_INTERVAL_MS = Math.max(10_000, Number(process.env.READER_AUTO_WATCH_INTERVAL_MS || 15_000));
const READER_AUTO_WATCH_TIMEOUT_MS = Math.max(60_000, Number(process.env.READER_AUTO_WATCH_TIMEOUT_MS || 300_000));
const readerWatchLocks = new Set();
const readerCheckLocks = new Set();
const readerCheckLastAt = new Map();
const paymentTxnLocks = new Set();
const paymentTxnLastAt = new Map();
const PAYMENT_TXN_SUBMIT_COOLDOWN_MS = Math.max(10_000, Number(process.env.PAYMENT_TXN_SUBMIT_COOLDOWN_MS || 15_000));

async function getPaymentReaderState() {
    if (TRUSTED_READER_UIDS.size === 0) {
        return { online: false, lastSeenAt: null, deviceUid: null, reason: "trusted_reader_not_configured" };
    }
    try {
        const checks = await Promise.all([...TRUSTED_READER_UIDS].map(async uid => {
            const snap = await db.ref(`reader_devices/${uid}`).once("value");
            return { uid, record: snap.val() || null };
        }));
        const now = Date.now();
        const onlineRecords = checks.filter(({ record }) => {
            const lastSeenAt = Number(record && record.lastSeenAt);
            return !!record && record.enabled === true && Number.isFinite(lastSeenAt) &&
                lastSeenAt > 0 && (now - lastSeenAt) >= 0 && (now - lastSeenAt) <= READER_ONLINE_WINDOW_MS;
        }).sort((a, b) => Number(b.record.lastSeenAt) - Number(a.record.lastSeenAt));
        if (!onlineRecords.length) return { online: false, lastSeenAt: null, deviceUid: null, reason: "heartbeat_missing_or_stale" };
        return { online: true, lastSeenAt: Number(onlineRecords[0].record.lastSeenAt), deviceUid: onlineRecords[0].uid, reason: null };
    } catch (err) {
        console.error("Payment Reader status lookup failed:", err.message);
        return { online: false, lastSeenAt: null, deviceUid: null, reason: "firebase_error" };
    }
}

function normalizeBangladeshPaymentNumber(value) {
    const raw = String(value || "").trim();
    if (!raw || /x{3,}|your|paste|placeholder/i.test(raw)) return "";
    const digits = raw.replace(/\D/g, "");
    if (/^01[3-9]\d{8}$/.test(digits)) return digits;
    if (/^8801[3-9]\d{8}$/.test(digits)) return `+${digits}`;
    return "";
}
let PAYMENT_NUMBERS = {
    bkash: normalizeBangladeshPaymentNumber(process.env.BKASH_PAYMENT_NUMBER),
    nagad: normalizeBangladeshPaymentNumber(process.env.NAGAD_PAYMENT_NUMBER)
};
function getPaymentNumber(provider) {
    return PAYMENT_NUMBERS[String(provider || "").toLowerCase()] || "";
}
function getProviderLabel(provider) {
    return provider === "bkash" ? "bKash" : provider === "nagad" ? "Nagad" : "Unknown";
}

async function findTrustedReaderEvent(txnId) {
    const normalizedTxnId = String(txnId || "").trim().toUpperCase();
    if (!normalizedTxnId || TRUSTED_READER_UIDS.size === 0) return null;
    const snapshots = await Promise.all([...TRUSTED_READER_UIDS].map(async uid => {
        const snap = await db.ref(`reader_events/${uid}`).once("value");
        return { uid, events: snap.val() || {} };
    }));
    for (const { uid, events } of snapshots) {
        for (const [eventKey, event] of Object.entries(events)) {
            const id = String((event && event.transactionId) || eventKey).trim().toUpperCase();
            if (event && id === normalizedTxnId) return { uid, eventKey, event };
        }
    }
    return null;
}

async function waitForTrustedReaderEvent(txnId, waitMs = 12_000, intervalMs = 1_500) {
    const stopAt = Date.now() + waitMs;
    do {
        const match = await findTrustedReaderEvent(txnId);
        if (match) return match;
        if (Date.now() < stopAt) await new Promise(resolve => setTimeout(resolve, intervalMs));
    } while (Date.now() < stopAt);
    return null;
}

async function autoWatchReaderOnline(interaction, category, sessionRef, provider) {
    const sessionKey = `${interaction.user.id}:${category}`;
    if (readerWatchLocks.has(sessionKey)) return;
    readerWatchLocks.add(sessionKey);
    const initialSnap = await sessionRef.once("value").catch(() => null);
    const initialSession = initialSnap?.val() || null;
    const initialCreatedAt = Number(initialSession?.createdAt) || 0;
    const deadline = Date.now() + READER_AUTO_WATCH_TIMEOUT_MS;
    try {
        if (!initialCreatedAt || String(initialSession?.provider || "") !== provider) return;
        while (Date.now() < deadline) {
            await new Promise(resolve => setTimeout(resolve, READER_AUTO_WATCH_INTERVAL_MS));
            const snap = await sessionRef.once("value");
            const current = snap.val();
            if (!current || Number(current.createdAt) !== initialCreatedAt || String(current.provider || "") !== provider) return;
            if (["creating", "completed"].includes(String(current.status || ""))) return;
            if (current.status === "awaiting_txn" && Number(current.numberShownAt) > 0) return;

            const readerState = await getPaymentReaderState();
            if (!readerState.online) continue;

            const paymentNumber = getPaymentNumber(provider);
            const updatedSession = {
                ...current,
                lastReaderCheckAt: Date.now(),
                readerCheckedAt: Date.now()
            };
            if (paymentNumber) {
                updatedSession.status = "awaiting_txn";
                updatedSession.readerDeviceUid = readerState.deviceUid;
                updatedSession.numberShownAt = Date.now();
            } else {
                updatedSession.status = "number_not_configured";
            }
            await sessionRef.update(updatedSession);
            await interaction.editReply({ content: "", ...buildPaymentPage(category, updatedSession, readerState, paymentNumber) });
            return;
        }

        const finalSnap = await sessionRef.once("value").catch(() => null);
        const finalSession = finalSnap?.val() || null;
        if (!finalSession || Number(finalSession.createdAt) !== initialCreatedAt || String(finalSession.provider || "") !== provider || ["creating", "completed"].includes(String(finalSession.status || ""))) return;
        const providerLabel = getProviderLabel(provider);
        const timeoutEmbed = new EmbedBuilder()
            .setTitle("🟠 ONLINE CHECK — Reader এখনও offline")
            .setDescription(
                `📦 **প্যাকেজ:** \`${String(category).toUpperCase()}\`\n` +
                `💳 **পেমেন্ট:** ${providerLabel}\n\n` +
                `${Math.round(READER_AUTO_WATCH_TIMEOUT_MS / 60000)} মিনিটের মধ্যে trusted Reader online পাওয়া যায়নি। নিরাপত্তার জন্য নম্বর দেখানো হয়নি। Reader online হওয়ার পর Shop থেকে package নির্বাচন করে নতুন checkout শুরু করুন। এই page-এ বারবার click করার দরকার নেই।`
            )
            .setColor("Orange").setTimestamp();
        await interaction.editReply({ content: "", embeds: [timeoutEmbed], components: [] });
    } catch (err) {
        console.error("Automatic Reader online watch failed:", err.message);
        // Keep the last fail-closed ONLINE CHECK page visible; never reveal a number on an error.
    } finally {
        readerWatchLocks.delete(sessionKey);
    }
}

function buildPaymentPage(category, session, readerState, providerNumber) {
    const provider = String(session.provider || "").toLowerCase();
    const providerLabel = getProviderLabel(provider);
    const totalPaid = Number(session.totalPaid) || 0;
    const targetPrice = Math.max(0, Number(session.targetPrice) || 0);
    const basePrice = Math.max(0, Number(session.basePrice) || targetPrice);
    const appliedDiscount = Math.max(0, Number(session.appliedDiscount) || 0);
    const remainingDue = Math.max(0, targetPrice - totalPaid);

    if (!readerState.online) {
        const unconfigured = TRUSTED_READER_UIDS.size === 0;
        const reason = unconfigured
            ? "Payment Reader-এর trusted device UID server config-এ সেট করা নেই।"
            : "Payment Reader offline, অথবা heartbeat পুরোনো।";
        const autoCheckText = unconfigured
            ? "Server config-এ trusted Reader UID যোগ হলে auto-check কাজ করবে। এই অবস্থায় পেমেন্ট নম্বর লুকানো থাকবে।"
            : `Bot নিজে প্রতি ${Math.round(READER_AUTO_WATCH_INTERVAL_MS / 1000)} সেকেন্ডে ONLINE CHECK করবে (সর্বোচ্চ ${Math.round(READER_AUTO_WATCH_TIMEOUT_MS / 60000)} মিনিট)। আবার button click বা command করার দরকার নেই।`;
        const embed = new EmbedBuilder()
            .setTitle("🟠 ONLINE CHECK")
            .setDescription(
                `📦 **প্যাকেজ:** \`${String(category).toUpperCase()}\`\n` +
                `💳 **পেমেন্ট:** ${providerLabel}\n` +
                `💰 **বকেয়া:** \`${remainingDue}\` BDT\n\n` +
                `🔒 **পেমেন্ট নম্বর লুকানো আছে।** ${reason}\n` +
                autoCheckText
            )
            .setColor("Orange").setTimestamp();
        return { embeds: [embed], components: [] };

    }

    if (!providerNumber) {
        const embed = new EmbedBuilder()
            .setTitle("⚠️ ONLINE CHECK — নম্বর সেট করা নেই")
            .setDescription(`Reader অনলাইন, কিন্তু ${providerLabel}-এর payment number server environment-এ সেট করা নেই। নিরাপত্তার জন্য কোনো নম্বর দেখানো হয়নি।`)
            .setColor("Orange").setTimestamp();
        return { embeds: [embed], components: [] };
    }

    const isPartial = totalPaid > 0;
    const discountText = session.appliedCoupon
        ? `\n🎟️ **Coupon:** \`${String(session.appliedCoupon)}\` (ছাড়: ${Number(session.appliedDiscount) || 0} BDT)`
        : "";
    const embed = new EmbedBuilder()
        .setTitle(`💳 ${providerLabel} Payment — ${String(category).toUpperCase()}`)
        .setDescription(
            `🟢 **ONLINE CHECK: সফল** — Reader এখন অনলাইন।\n\n` +
            `📦 **প্যাকেজ:** \`${String(category).toUpperCase()}\`\n` +
            `💰 **প্যাকেজের মূল্য:** \`${basePrice}\` BDT\n` +
            (appliedDiscount > 0 ? `🎟️ **কুপন ছাড়:** \`${appliedDiscount}\` BDT\n` : "") +
            `💳 **ছাড়ের পর পরিশোধযোগ্য:** \`${targetPrice}\` BDT\n` +
            (isPartial ? `✅ **আগে পাওয়া পেমেন্ট:** \`${totalPaid}\` BDT\n📉 **এখন বকেয়া:** \`${remainingDue}\` BDT\n` : "") +
            `📱 **${providerLabel} নম্বর:** \`${providerNumber}\`\n` +
            `\nটাকা পাঠানোর পর payment notification-এ পাওয়া Transaction ID নিচের বাটনে জমা দিন।` +
            discountText +
            `\n\n⚠️ TxnID trusted Reader notification-এর সঙ্গে স্বয়ংক্রিয়ভাবে মিলিয়ে দেখা হবে।`
        )
        .setColor("Green").setTimestamp();
    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`submit_txn_${category}`).setLabel(isPartial ? "➕ Submit Additional TxnID" : "TxnID জমা দিন").setStyle(ButtonStyle.Primary)
    );
    return { embeds: [embed], components: [row] };
}

const app = express();
app.get("/", (req, res) => { res.send("Bot is running!"); });
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => { console.log(`🌐 Web server running on port ${PORT}`); });

// ================================
// 📱 Dynamic Realtime Settings (Firebase Sync)
// ================================

let VERIFICATION_LINK = "https://discord.gg/example"; // existing non-payment setting

// Optional Firebase override. Environment variables allow setup without seeding payment data in Firebase.
db.ref("settings").on("value", (snapshot) => {
    const data = snapshot.val() || {};
    const numbers = data.payment_numbers || {};
    PAYMENT_NUMBERS = {
        bkash: normalizeBangladeshPaymentNumber(numbers.bkash || data.bkash_payment_number || process.env.BKASH_PAYMENT_NUMBER),
        nagad: normalizeBangladeshPaymentNumber(numbers.nagad || data.nagad_payment_number || process.env.NAGAD_PAYMENT_NUMBER)
    };
    if (data.verification_link) VERIFICATION_LINK = String(data.verification_link);
});

// ================================
// ⚙️ Bot Config & Automod Rules
// ================================

const TOKEN = process.env.TOKEN;
const ALLOWED_GUILD_ID = "1488101970425155584";
const VERIFIED_ROLE_ID = "1488333841402691664";

const WELCOME_CHANNEL_ID = "1488339169821593731";
const LOG_CHANNEL_ID = "1488340400673656973";

// অর্ডার ট্র্যাকিং চ্যানেল আইডি
const ORDER_TRACKING_CHANNEL_ID = "1488340262827855983"; 
// নতুন অর্ডার গাইড চ্যানেল আইডি
const ORDER_GUIDE_CHANNEL_ID = "1488339045602951199";

// ১-টাইম কী জেনারেটর চ্যানেল আইডি
const ONETIME_KEY_CHANNEL_IDS = ["1488340757160005683"];

const ROLES = {
    ADMIN: "1488332568372973568", 
    SUPPORT_TICKET_REPORT: "1488333580705861765", 
    SUPPORT_CUSTOMER: "1488335064873046086",
    DEVELOPER: "1523955414612578354" // Developer রোলের ID
};

const CHANNELS = {
    TICKET_PANEL: "1488339982627115118",
    REPORT_PANEL: "1488340441115004999",
    CUSTOMER_PANEL: "1488340017938960484",
    BUY_PANEL: "1488339666368462858", 
    PAYMENT_PANEL: "1488339666368462858" 
};

const COVER_IMAGES = {
    VERIFY: "https://cdn.discordapp.com/attachments/1488338142607184055/1488761437550678056/5cfd1fe4-d12c-4439-b374-f386f7595184.png",
    TICKET: "https://cdn.discordapp.com/attachments/1488338142607184055/1488761437550678056/5cfd1fe4-d12c-4439-b374-f386f7595184.png", 
    REPORT: "https://cdn.discordapp.com/attachments/1488338142607184055/1488761437550678056/5cfd1fe4-d12c-4439-b374-f386f7595184.png",
    CUSTOMER: "https://cdn.discordapp.com/attachments/1488338142607184055/1488761437550678056/5cfd1fe4-d12c-4439-b374-f386f7595184.png",
    PAYMENT: "https://cdn.discordapp.com/attachments/1488338142607184055/1488761437550678056/5cfd1fe4-d12c-4439-b374-f386f7595184.png"
};

const BAD_WORDS = ["gali1", "gali2", "gali3", "khanki", "magi", "baimon"]; 

// 💰 প্যাকেজের মূল্য তালিকা
const PACKAGE_PRICES = {
    weekly: 510,
    weekly_plan: 510,
    monthly: 1510,
    monthly_plan: 1510,
    "2_months": 2410,
    two_months_plan: 2410,
    two: 2410,
    "2months": 2410,
    "2month": 2410,
    two_months: 2410
};

function getNormalizedCategory(cat) {
    const c = String(cat || "weekly").toLowerCase().trim();
    if (["2_months", "two_months", "two_months_plan", "two", "2months", "2month"].includes(c) || c.includes("two") || c.includes("2")) return "2_months";
    if (["monthly", "monthly_plan", "month"].includes(c) || c.includes("month")) return "monthly";
    if (["weekly", "weekly_plan", "week"].includes(c) || c.includes("week")) return "weekly";
    return "weekly";
}

// New Configs
const STATS_VC_CHANNEL_ID = "1524321192079786005";
const LEVEL_ROLE_ID = "1524322087295127552";
const GIVEAWAY_CHANNEL_ID = "1488341249739198585";
const EMBED_NOTICE_CHANNEL_ID = "1488338739850772641";
const SOCIAL_FEED_CHANNEL_ID = "1488338739850772641";
const STAFF_ADMIN_LOG_ID = "1524324771502882877";
const WEEKLY_REPORT_CHANNEL_ID = "1524326280923709550";
const TRANSCRIPT_LOG_CHANNEL_ID = "1524326928268660807";

// Databases
const DATA_FILE = "./database.json";
const WELCOME_LOG_FILE = "./welcome_messages.json";
const PUNISH_FILE = "./punishments.json"; 
const ORDER_LOG_FILE = "./order_tracking.json"; 

const cooldowns = new Map();
const userMsgCounter = new Map(); 
const userWarns = new Map(); 

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildMessageReactions
    ],
    partials: [Partials.Channel, Partials.GuildMember, Partials.Message, Partials.Reaction]
});

process.on("unhandledRejection", (err) => {
    console.error("[Unhandled Rejection]", err);
});
process.on("uncaughtException", (err) => {
    console.error("[Uncaught Exception] Fatal error; shutting down so the process manager can restart the bot.", err);
    process.exit(1);
});

// 🎲 ইউনিক কুপন কোড জেনারেটর (e.g., AK-A1B2C3)
function generateSecureBase36(length) {
    const range = 36n ** BigInt(length);
    return (crypto.randomBytes(8).readBigUInt64BE(0) % range)
        .toString(36)
        .toUpperCase()
        .padStart(length, "0");
}

function generateUniqueCouponCode() {
    // Keep the existing AK-XXXXXX format so existing panels/users remain compatible.
    return `AK-${generateSecureBase36(6)}`;
}


// Auto coupon defaults ON for users who have not saved a preference yet.
async function isAutoCouponEnabled(userId) {
    const snap = await db.ref(`user_settings/${userId}/autoCouponEnabled`).once("value");
    return snap.exists() ? snap.val() === true : true;
}

function getCouponBalance(coupon) {
    const balance = Number(coupon?.remainingValue ?? coupon?.couponValue ?? coupon?.discountValue ?? 0);
    return Number.isFinite(balance) && balance > 0 ? balance : 0;
}

async function reserveBestAutoCoupon(userId, category, basePrice) {
    const snap = await db.ref("coupons").once("value");
    const allCoupons = snap.val() || {};
    const now = Date.now();
    const candidates = Object.entries(allCoupons)
        .map(([code, data]) => ({ code, data: data || {} }))
        .filter(({ data }) => data.userId === userId && data.status === "active" &&
            (!data.expiresAt || Number(data.expiresAt) > now) && getCouponBalance(data) > 0)
        .sort((a, b) => {
            const aExpiry = Number(a.data.expiresAt) || Number.MAX_SAFE_INTEGER;
            const bExpiry = Number(b.data.expiresAt) || Number.MAX_SAFE_INTEGER;
            return aExpiry - bExpiry || getCouponBalance(b.data) - getCouponBalance(a.data);
        });

    for (const candidate of candidates) {
        const couponRef = db.ref(`coupons/${candidate.code}`);
        const reservation = await couponRef.transaction((current) => {
            const time = Date.now();
            if (!current || current.status !== "active" || current.userId !== userId ||
                (current.expiresAt && Number(current.expiresAt) <= time) || getCouponBalance(current) <= 0) return;
            const heldByOtherCheckout = current.reservedBy &&
                !(current.reservedBy === userId && current.reservedCategory === category) &&
                (time - (Number(current.reservedAt) || 0) < 30 * 60 * 1000);
            if (heldByOtherCheckout) return;
            return { ...current, reservedBy: userId, reservedCategory: category, reservedAt: time };
        }, undefined, false);
        if (!reservation.committed) continue;
        const coupon = reservation.snapshot.val() || {};
        const balance = getCouponBalance(coupon);
        const discount = Math.min(Math.max(0, Number(basePrice) || 0), balance);
        if (discount <= 0) continue;
        return { code: candidate.code, balance, discount, coupon };
    }
    return null;
}

async function consumeCouponBalance(code, userId, category, requestedAmount) {
    if (!code) return { committed: false, remainingValue: 0 };
    const amountToConsume = Math.max(0, Number(requestedAmount) || 0);
    const couponRef = db.ref(`coupons/${code}`);
    return couponRef.transaction((current) => {
        if (!current || current.status !== "active" || current.userId !== userId) return;
        if (current.reservedBy && (current.reservedBy !== userId || current.reservedCategory !== category)) return;
        const balance = getCouponBalance(current);
        if (balance <= 0 || amountToConsume <= 0) return;
        const consumed = Math.min(balance, amountToConsume);
        const remainingValue = Math.max(0, Math.round((balance - consumed) * 100) / 100);
        return {
            ...current,
            remainingValue,
            status: remainingValue > 0 ? "active" : "used",
            lastUsedBy: userId,
            lastUsedAt: Date.now(),
            lastConsumedValue: consumed,
            ...(remainingValue > 0 ? { reservedBy: null, reservedCategory: null, reservedAt: null } : {
                usedBy: userId, usedAt: Date.now(), reservedBy: null, reservedCategory: null, reservedAt: null
            })
        };
    }, undefined, false);
}

async function releaseCouponReservation(code, userId, category) {
    if (!code) return;
    await db.ref(`coupons/${code}`).transaction((current) => {
        if (!current || current.status !== "active" || current.reservedBy !== userId || current.reservedCategory !== category) return;
        return { ...current, reservedBy: null, reservedCategory: null, reservedAt: null };
    }, undefined, false).catch(() => {});
}

// 📌 Firebase থেকে ডেটা নিয়ে আসার ফাংশন
async function fetchFirebasePanelData(panelType) {
    try {
        const snapshot = await db.ref(`panels/${panelType}`).once("value");
        const data = snapshot.val() || {};
        
        const customDescription = data.description || null;
        const customImage = data.image || null;

        let rawOptions = [];
        if (data.options && typeof data.options === "object") {
            rawOptions = Object.keys(data.options).map(key => {
                const item = data.options[key];
                const isObject = item !== null && typeof item === "object";
                return {
                    label: String(isObject ? (item.label ?? key) : (item ?? key)).trim().slice(0, 100),
                    value: String(isObject ? (item.value ?? key) : key).trim().slice(0, 80),
                    ...(isObject && item.description ? { description: String(item.description).trim().slice(0, 100) } : {})
                };
            });
        } else {
            rawOptions = Object.keys(data)
                .filter(key => !["description", "image", "title", "options"].includes(key))
                .map(key => ({ label: String(data[key] ?? key).trim().slice(0, 100), value: String(key).trim().slice(0, 80) }));
        }

        const usedValues = new Set();
        const options = rawOptions
            .filter(option => option.label && option.value && !usedValues.has(option.value) && usedValues.add(option.value))
            .slice(0, 25);

        if (options.length === 0 && panelType === "payment") {
            // Built-in package options mean the shop can start without manually seeding panel data in Firebase.
            options.push(
                { label: `Weekly — ${PACKAGE_PRICES.weekly} BDT`, value: "weekly" },
                { label: `Monthly — ${PACKAGE_PRICES.monthly} BDT`, value: "monthly" },
                { label: `2 Months — ${PACKAGE_PRICES["2_months"]} BDT`, value: "2_months" }
            );
        } else if (options.length === 0) {
            options.push({ label: "No Options Found", value: "none" });
        }

        return { options, customDescription, customImage, fullData: data };
    } catch (error) {
        console.error(`❌ Firebase Panel Data Fetch Error (${panelType}):`, error);
        return { 
            options: [{ label: "Error Loading Data", value: "error" }], 
            customDescription: null, 
            customImage: null,
            fullData: {}
        };
    }
}

// ================================
// 🔑 Key Generation Core Function
// ================================
async function handleOneTimeKeyGeneration(interaction) {
    const member = interaction.member;
    const hasDevRole = Boolean(member?.roles?.cache?.has(ROLES.DEVELOPER));
    const isAdmin = Boolean(member?.permissions?.has(PermissionFlagsBits.Administrator));

    if (!hasDevRole && !isAdmin) {
        return interaction.reply({
            content: "❌ **অনুমতি নেই!** শুধুমাত্র **Developer** রোলধারীরা C++ অ্যাপের জন্য 1TIME KEY তৈরি করতে পারবেন।",
            flags: [MessageFlags.Ephemeral]
        });
    }

    try {
        const userAvatarUrl = interaction.user.displayAvatarURL({ extension: "png", size: 512 });
        const serverName = interaction.guild?.name || "Discord Server";
        let randomKey = null;

        // Collision হলে পুরোনো key overwrite না করে নতুন key তৈরি করে।
        for (let attempt = 0; attempt < 5 && !randomKey; attempt++) {
            // Keep the original KEY-XXXXXX-1234 format for C++ client compatibility.
            const candidate = `KEY-${generateSecureBase36(6)}-${Date.now().toString().slice(-4)}`;
            const keyRef = db.ref(`keys/${candidate}`);
            const result = await keyRef.transaction((current) => current === null ? {
                used: false,
                generatedBy: interaction.user.tag,
                username: interaction.user.username,
                userId: interaction.user.id,
                avatarUrl: userAvatarUrl,
                serverName,
                createdAt: Date.now()
            } : undefined, undefined, false);
            if (result.committed) randomKey = candidate;
        }

        if (!randomKey) throw new Error("Could not allocate a unique one-time key after several attempts.");

        const keyEmbed = new EmbedBuilder()
            .setTitle("🔑 1TIME KEY Generated Successfully!")
            .setDescription(`আপনার ১-টাইম কী সফলভাবে তৈরি হয়েছে। C++ অ্যাপে লগইন করতে নিচের কী-টি ব্যবহার করুন:\n\n**KEY:** \`${randomKey}\``)
            .setThumbnail(userAvatarUrl)
            .setColor("#57F287")
            .setFooter({ text: "নোট: এই কী-টি C++ অ্যাপে কেবল একবারই ব্যবহার করা যাবে।" });

        return interaction.reply({ embeds: [keyEmbed], flags: [MessageFlags.Ephemeral] });
    } catch (err) {
        console.error("❌ One-time key generation failed:", err);
        const payload = { content: "❌ কী তৈরি করা যায়নি। Firebase configuration/permission পরীক্ষা করে আবার চেষ্টা করুন।", flags: [MessageFlags.Ephemeral] };
        if (interaction.replied || interaction.deferred) return interaction.followUp(payload).catch(() => {});
        return interaction.reply(payload).catch(() => {});
    }
}

// ================================
// 📂 Database Helper Functions
// ================================

function getSavedMembers() { if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, JSON.stringify([]), "utf8"); return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
function saveMembers(memberIds) { fs.writeFileSync(DATA_FILE, JSON.stringify(memberIds, null, 2), "utf8"); }
function getWelcomeLogs() { if (!fs.existsSync(WELCOME_LOG_FILE)) fs.writeFileSync(WELCOME_LOG_FILE, JSON.stringify({}), "utf8"); return JSON.parse(fs.readFileSync(WELCOME_LOG_FILE, "utf8")); }
function saveWelcomeLog(userId, messageId, data = {}) { const logs = getWelcomeLogs(); logs[userId] = { messageId, ...data }; fs.writeFileSync(WELCOME_LOG_FILE, JSON.stringify(logs, null, 2), "utf8"); }
function getPunishments() { if (!fs.existsSync(PUNISH_FILE)) fs.writeFileSync(PUNISH_FILE, JSON.stringify({}), "utf8"); return JSON.parse(fs.readFileSync(PUNISH_FILE, "utf8")); }
function savePunishment(userId, status, durationMs = null) { const punishments = getPunishments(); if (status === null) { delete punishments[userId]; } else { punishments[userId] = { status: status, time: Date.now(), expiresAt: durationMs ? Date.now() + durationMs : null }; } fs.writeFileSync(PUNISH_FILE, JSON.stringify(punishments, null, 2), "utf8"); }
function getOrderLogs() { if (!fs.existsSync(ORDER_LOG_FILE)) fs.writeFileSync(ORDER_LOG_FILE, JSON.stringify({}), "utf8"); return JSON.parse(fs.readFileSync(ORDER_LOG_FILE, "utf8")); }
function saveOrderLog(channelId, trackingMessageId, orderDetails) { const logs = getOrderLogs(); logs[channelId] = { trackingMessageId, ...orderDetails }; fs.writeFileSync(ORDER_LOG_FILE, JSON.stringify(logs, null, 2), "utf8"); }

// ================================
// 🎉 Dynamic Welcome Embed Builder
// ================================

function buildDynamicWelcomeEmbed(member, status, isOfflineHook = false, verifyTime = null) {
    let statusText = "❌ Unverified"; let color = "#FFA500"; 
    let thumbnail = member.user ? member.user.displayAvatarURL({ dynamic: true }) : null;
    let tag = member.user ? member.user.tag : member.userId || "Unknown Member";
    let id = member.id || member.userId;
    let joinedTime = member.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : "Unknown";

    if (status === "verified") { statusText = "✅ Verified"; color = "#00FF00"; }
    else if (status === "left") { statusText = "🚫 Left Server"; color = "#FF0000"; }

    const embed = new EmbedBuilder().setColor(color).setTitle("🎉 নতুন সদস্য ট্র্যাকিং সিস্টেম").setDescription(`✨ স্বাগতম <@${id}> আমাদের সার্ভারে!\n📜 আমাদের নিয়মগুলো মেনে চলার অনুরোধ রইল। ❤️`).addFields({ name: "👤 Username", value: `${tag}`, inline: true }, { name: "🆔 User ID", value: `${id}`, inline: true }, { name: "⏰ Joined Server", value: joinedTime, inline: true }, { name: "🛡️ Verification Status", value: `**${statusText}**`, inline: true }).setTimestamp();
    if (thumbnail) embed.setThumbnail(thumbnail);
    if (member.guild) embed.addFields({ name: "👥 Total Members", value: `${member.guild.memberCount}`, inline: true });
    if (verifyTime) embed.addFields({ name: "⚡ Verified At", value: `<t:${Math.floor(verifyTime / 1000)}:R>`, inline: true });
    if (isOfflineHook) embed.setFooter({ text: "⚠️ বট অফলাইন থাকার সময় এই অ্যাকশনটি ঘটেছিল।" });
    else embed.setFooter({ text: "Professional Security Management System" });
    return embed;
}

// New member welcome tracking (required for the verification handler to update its welcome embed).
client.on("guildMemberAdd", async (member) => {
    if (member.guild.id !== ALLOWED_GUILD_ID) return;
    try {
        const welcomeChannel = member.guild.channels.cache.get(WELCOME_CHANNEL_ID);
        if (!welcomeChannel) {
            console.error("❌ Welcome channel not found:", WELCOME_CHANNEL_ID);
            return;
        }
        const welcomeMessage = await welcomeChannel.send({ embeds: [buildDynamicWelcomeEmbed(member, "unverified")] });
        saveWelcomeLog(member.id, welcomeMessage.id, { isOffline: false, status: "unverified", joinedAt: Date.now() });
    } catch (error) {
        console.error("❌ Failed to post welcome message:", error.message);
    }
});

client.on("guildMemberRemove", async (member) => {
    if (member.guild.id !== ALLOWED_GUILD_ID) return;
    try {
        const logs = getWelcomeLogs();
        const userLog = logs[member.id];
        if (!userLog?.messageId) return;
        const welcomeChannel = member.guild.channels.cache.get(WELCOME_CHANNEL_ID);
        if (!welcomeChannel) return;
        const welcomeMessage = await welcomeChannel.messages.fetch(userLog.messageId);
        await welcomeMessage.edit({ embeds: [buildDynamicWelcomeEmbed(member, "left", Boolean(userLog.isOffline))] });
        saveWelcomeLog(member.id, userLog.messageId, { ...userLog, status: "left", leftAt: Date.now() });
    } catch (error) {
        console.error("❌ Failed to update leave tracking:", error.message);
    }
});

// ================================
// 🛒 Order Status Embed Builder
// ================================
function buildOrderStatusEmbed(user, category, ticketChannel, status, staff = null, reason = null, txnId = null) {
    let color = "#FFFF00"; let statusString = "⏳ PENDING (অপেক্ষমাণ)";
    
    if (status === "approved") { color = "#00FF00"; statusString = `✅ APPROVED & RUNNING (কাজ চলছে)`; }
    else if (status === "closed") { color = "#FF0000"; statusString = "🔒 CLOSED (টিকিট বন্ধ করা হয়েছে)"; }
    else if (status === "banned") { color = "#2F3136"; statusString = `🚫 FAKE TICKET BAN (${reason || "ফানি টিকিট"})`; }

    const embed = new EmbedBuilder()
        .setTitle("📦 ORDER TRACKING SYSTEM")
        .setColor(color)
        .addFields(
            { name: "👤 কাস্টমার", value: `${user}`, inline: true },
            { name: "🛒 প্রোডাক্ট/ক্যাটাগরি", value: `\`${category.toUpperCase().replace("_", " ")}\``, inline: true },
            { name: "📁 টিকিট চ্যানেল", value: `${ticketChannel}`, inline: true },
            { name: "📊 বর্তমান স্ট্যাটাস", value: `**${statusString}**`, inline: false }
        )
        .setTimestamp()
        .setFooter({ text: "Order Update System" });

    if (txnId) {
        let maskedTxnId = txnId;
        if (txnId.length > 4) {
            maskedTxnId = txnId.substring(0, 2) + "****" + txnId.substring(txnId.length - 2);
        } else {
            maskedTxnId = "****";
        }
        embed.addFields({ name: "💳 Transaction ID", value: `\`${maskedTxnId}\``, inline: true });
    }
    
    if (staff) embed.addFields({ name: "🛟 দায়িত্বপ্রাপ্ত স্টাফ", value: `${staff}`, inline: true });
    return embed;
}

// XP transaction callback must remain side-effect free: Firebase may retry it.
async function awardMessageXp(message) {
    const xpRef = db.ref(`leveling/${message.author.id}`);
    let previousLevel = 1;
    const result = await xpRef.transaction((current) => {
        const old = current && typeof current === "object" ? current : { xp: 0, level: 1 };
        const level = Math.max(1, Number.parseInt(old.level, 10) || 1);
        const gainedXp = crypto.randomInt(5, 10);
        let xp = Math.max(0, Number(old.xp) || 0) + gainedXp;
        let nextLevel = level;
        previousLevel = level;
        while (xp >= nextLevel * 100) {
            xp -= nextLevel * 100;
            nextLevel += 1;
        }
        return { xp, level: nextLevel };
    }, undefined, false);

    if (!result.committed) return;
    const finalData = result.snapshot.val() || {};
    const finalLevel = Number(finalData.level) || 1;
    if (finalLevel > previousLevel) {
        await message.channel.send(`🎉 অভিনন্দন <@${message.author.id}>! আপনি লেভেল **${finalLevel}** এ উন্নীত হয়েছেন।`)
            .then(m => setTimeout(() => m.delete().catch(() => {}), 5000))
            .catch(() => {});
        await message.member.roles.add(LEVEL_ROLE_ID).catch(() => {});
    }
}

// Ghost Ping ট্র্যাকিং
client.on("messageDelete", async (message) => {
    if (!message.guild || message.author?.bot) return;
    if (message.mentions.users.size > 0 || message.mentions.roles.size > 0) {
        const targets = [...message.mentions.users.values()].map(u => u.toString()).join(" ") || [...message.mentions.roles.values()].map(r => r.toString()).join(" ");
        const ghostEmbed = new EmbedBuilder()
            .setColor("Red")
            .setTitle("🛑 Ghost Ping Detected")
            .setDescription(`**কারা করেছে:** ${message.author}\n**চ্যানেল:** ${message.channel}\n**যাকে ট্যাগ করা হয়েছিল:** ${targets}\n**মেসেজ:** ${message.content || "*কোনো লেখা নেই*"}`)
            .setTimestamp();
        message.channel.send({ embeds: [ghostEmbed] }).then(m => setTimeout(() => m.delete().catch(() => {}), 10000));
    }
});

// Automod + Activity XP System
client.on("messageCreate", async (message) => {
    if (message.author.bot || !message.guild || message.guild.id !== ALLOWED_GUILD_ID) return;
    if (message.member.permissions.has(PermissionFlagsBits.Administrator) || message.member.roles.cache.has(ROLES.ADMIN)) return;
    
    const userId = message.author.id; 
    let triggerAutomod = false; 
    let reason = "";
    const contentLower = message.content.toLowerCase();

    // 🛑 Caps-Lock Protection
    const upperCount = message.content.replace(/[^A-Z]/g, "").length;
    const totalLetters = message.content.replace(/[^a-zA-Z]/g, "").length;
    if (totalLetters > 5 && (upperCount / totalLetters) > 0.7) {
        try { await message.delete().catch(() => {}); } catch(e){}
        const capsWarn = await message.channel.send(`⚠️ <@${userId}>, মেসেজে অতিরিক্ত বড় হাতের অক্ষর (Caps Lock) ব্যবহার করবেন না।`);
        setTimeout(() => capsWarn.delete().catch(() => {}), 5000);
        return;
    }

    // Anti-Link Spam
    const linkRegex = /(https?:\/\/[^\s]+)/g;
    if (linkRegex.test(message.content)) {
        try { await message.delete().catch(() => {}); } catch(e){}
        const linkWarn = await message.channel.send(`⚠️ <@${userId}>, সার্ভারে কোনো প্রকার বাইরের লিংক ছড়ানো সম্পূর্ণ নিষিদ্ধ!`);
        setTimeout(() => linkWarn.delete().catch(() => {}), 5000);
        return;
    }

    // লাইভ লিঙ্ক রেসপন্স
    if (contentLower.includes("link") || contentLower.includes("লিংক") || contentLower.includes("লিঙ্ক")) {
        return message.reply(`👋 আপনি কি সার্ভার বা ভেরিফিকেশন লিংক খুঁজছেন? এই নিন আমাদের লাইভ লিংক:\n\`${VERIFICATION_LINK}\``);
    }

    if (BAD_WORDS.some(word => contentLower.includes(word))) { triggerAutomod = true; reason = "গালিগালাজ / নিষিদ্ধ শব্দ ব্যবহার"; }
    if (!triggerAutomod) {
        const now = Date.now(); if (!userMsgCounter.has(userId)) userMsgCounter.set(userId, []);
        const timestamps = userMsgCounter.get(userId); timestamps.push(now);
        const expirationTime = now - 5000; const activeTimestamps = timestamps.filter(time => time > expirationTime);
        userMsgCounter.set(userId, activeTimestamps);
        if (activeTimestamps.length >= 5) { triggerAutomod = true; reason = "অতিরিক্ত স্প্যামিং করা"; }
    }
    if (triggerAutomod) {
        try { await message.delete().catch(() => {}); } catch(e){}
        let warns = (userWarns.get(userId) || 0) + 1; userWarns.set(userId, warns);
        if (warns < 3) {
            const warnEmbed = new EmbedBuilder().setColor("Yellow").setDescription(`⚠️ <@${userId}>, সার্ভারে **${reason}** নিষিদ্ধ! আপনি এটি **${warns}/৩** বার করেছেন।`);
            const warnMsg = await message.channel.send({ embeds: [warnEmbed] }); setTimeout(() => warnMsg.delete().catch(() => {}), 5000);
        } else {
            userWarns.set(userId, 0);
            savePunishment(userId, "Muted", 10 * 60 * 1000);
            try {
                await message.member.timeout(10 * 60 * 1000, "Automod: Limit Exceeded");
                const muteEmbed = new EmbedBuilder().setColor("Red").setTitle("🚫 মেম্বার মিউটেড").setDescription(`<@${userId}> কে ১০ মিনিটের জন্য মিউট করা হয়েছে।`);
                await message.channel.send({ embeds: [muteEmbed] });
            } catch (err) {
                console.error("❌ Automod timeout failed:", err.message);
            }
        }
        return; // Deleted/flagged messages must not earn XP.
    }

    try {
        await awardMessageXp(message);
    } catch (err) {
        console.error("❌ XP transaction failed:", err.message);
    }
});

// ================================
// ⚡ PART 3 - Interaction Handling
// ================================

const verificationRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("universal_verify_button").setLabel("Verify Me").setStyle(ButtonStyle.Success)
);
function createVerificationEmbed() { return new EmbedBuilder().setTitle("🚨 Verification Required").setDescription("👇 নিচের বাটনে ক্লিক করে ভেরিফাই করুন").setColor("Blue").setImage(COVER_IMAGES.VERIFY).setTimestamp(); }

client.on("interactionCreate", async (interaction) => {
    if (!interaction.guild || interaction.guild.id !== ALLOWED_GUILD_ID) return;

    try {
    if (interaction.isButton() || interaction.isStringSelectMenu()) {
        const cooldownKey = `${interaction.user.id}-${interaction.customId}`;
        const paymentOnlineControl = interaction.customId.startsWith("pay_provider_") || interaction.customId.startsWith("check_reader_");
        if (cooldowns.has(cooldownKey) && !paymentOnlineControl && interaction.customId !== "universal_verify_button" && !interaction.customId.startsWith("giveaway_join_") && !interaction.customId.startsWith("star_rating_")) {
            return interaction.reply({ content: "⚠️ অনুরোধটি ইতোমধ্যে নেওয়া হয়েছে। কয়েক সেকেন্ড অপেক্ষা করুন।", flags: [MessageFlags.Ephemeral] });
        }
        if (!paymentOnlineControl) {
            cooldowns.set(cooldownKey, true);
            setTimeout(() => cooldowns.delete(cooldownKey), 3000);
        }
    }

    if (interaction.isButton() && interaction.customId === "toggle_auto_coupon") {
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
        try {
            const prefRef = db.ref(`user_settings/${interaction.user.id}/autoCouponEnabled`);
            const result = await prefRef.transaction(current => current === false ? true : false, undefined, false);
            const enabled = result.committed ? result.snapshot.val() === true : await isAutoCouponEnabled(interaction.user.id);
            const settingText = enabled
                ? "🟢 **Auto Coupon: ON** — পরের নতুন checkout-এ আপনার active coupon-এর উপযুক্ত অংশ নিজে থেকে ব্যবহার হবে।"
                : "⚪ **Auto Coupon: OFF** — পরের নতুন checkout-এ স্বয়ংক্রিয়ভাবে coupon ব্যবহার হবে না; চাইলে coupon code হাতে দিতে পারবেন।";
            return interaction.editReply(`${settingText}\nএই পরিবর্তন পরের নতুন checkout থেকে কার্যকর হবে।`);
        } catch (err) {
            console.error("Auto coupon preference toggle failed:", err.message);
            return interaction.editReply("❌ Auto Coupon সেটিং পরিবর্তন করা যায়নি। পরে আবার চেষ্টা করুন.");
        }
    }

    if (interaction.isButton() && interaction.customId === "universal_verify_button") {
        try {
            await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
            const role = interaction.guild.roles.cache.get(VERIFIED_ROLE_ID);
            if (!role) return interaction.editReply("❌ Role not found!");
            if (interaction.member.roles.cache.has(VERIFIED_ROLE_ID)) return interaction.editReply("⚠️ আপনি ইতোমধ্যে ভেরিফাই হয়েছেন।");
            await interaction.member.roles.add(role); await interaction.editReply("✅ সফলভাবে ভেরিফাই সম্পন্ন হয়েছে!");
            
            db.ref(`analytics/joins/${Date.now()}`).set(interaction.user.id);

            const logs = getWelcomeLogs(); const userLog = logs[interaction.user.id]; const welcomeChannel = interaction.guild.channels.cache.get(WELCOME_CHANNEL_ID);
            if (userLog && welcomeChannel) { try { const msg = await welcomeChannel.messages.fetch(userLog.messageId); if (msg) { const updatedEmbed = buildDynamicWelcomeEmbed(interaction.member, "verified", userLog.isOffline, Date.now()); await msg.edit({ embeds: [updatedEmbed] }); } } catch (e) {} }
        } catch (err) { console.error(err); }
        return;
    }

    // 🔑 Button ভিত্তিক OneTime Key Handler
    if (interaction.isButton() && (interaction.customId === "btn_generate_1time_key" || interaction.customId === "generate_1time_key")) {
        return handleOneTimeKeyGeneration(interaction);
    }

    // Giveaway বাটনে ক্লিক ট্র্যাকিং
    if (interaction.isButton() && interaction.customId.startsWith("giveaway_join_")) {
        const gwId = interaction.customId.split("_")[2];
        const participantRef = db.ref(`giveaways/${gwId}/participants/${interaction.user.id}`);
        const snap = await participantRef.once("value");
        if (snap.exists()) {
            return interaction.reply({ content: "❌ আপনি অলরেডি এই গিভঅ্যাওয়েতে জয়েন করেছেন!", flags: [MessageFlags.Ephemeral] });
        }
        await participantRef.set(interaction.user.tag);
        
        const fullSnap = await db.ref(`giveaways/${gwId}`).once("value");
        const gwData = fullSnap.val();
        const count = Object.keys(gwData.participants || {}).length;
        
        const embed = EmbedBuilder.from(interaction.message.embeds[0]);
        embed.setFields({ name: "🎉 এন্ট্রি সংখ্যা", value: `\`${count}\` জন মেম্বার`, inline: true });
        await interaction.message.edit({ embeds: [embed] });

        return interaction.reply({ content: "✅ আপনি সফলভাবে গিভঅ্যাওয়েতে নাম এন্ট্রি করেছেন!", flags: [MessageFlags.Ephemeral] });
    }

    // এডভান্সড টিকেট রেটিং ফিডব্যাক সিস্টেম
    if (interaction.isButton() && interaction.customId.startsWith("star_rating_")) {
        const [, , stars, staffId] = interaction.customId.split("_");
        
        const modal = new ModalBuilder().setCustomId(`modal_feedback_${stars}_${staffId}`).setTitle("📝 Ticket Support Feedback");
        const commentInput = new TextInputBuilder().setCustomId("feedback_comment").setLabel("আপনার মূল্যবান মতামতটি লিখুন (ঐচ্ছিক)").setStyle(TextInputStyle.Paragraph).setRequired(false);
        modal.addComponents(new ActionRowBuilder().addComponents(commentInput));
        return interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith("modal_feedback_")) {
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
        const [, , stars, staffId] = interaction.customId.split("_");
        const comment = interaction.fields.getTextInputValue("feedback_comment") || "কোনো কমেন্ট নেই।";
        
        const reviewChannel = interaction.guild.channels.cache.get(LOG_CHANNEL_ID);
        if (reviewChannel) {
            const reviewEmbed = new EmbedBuilder()
                .setTitle("⭐ NEW SUPPORT FEEDBACK")
                .setColor("Gold")
                .addFields(
                    { name: "👤 কাস্টমার", value: `${interaction.user}`, inline: true },
                    { name: "🛟 দায়িত্বপ্রাপ্ত স্টাফ", value: `<@${staffId}>`, inline: true },
                    { name: "📊 রেটিং স্কোর", value: `${"⭐".repeat(parseInt(stars))}`, inline: false },
                    { name: "💬 কাস্টমার কমেন্ট", value: `\`\`\`${comment}\`\`\``, inline: false }
                )
                .setTimestamp();
            await reviewChannel.send({ embeds: [reviewEmbed] });
        }
        return interaction.editReply("❤️ আপনার সুন্দর ফিডব্যাকটি দেওয়ার জন্য অসংখ্য ধন্যবাদ!");
    }

    // 🌟 ড্রপডাউন সিলেকশন হ্যান্ডলার (1TIME KEY + TICKET HANDLING + BUY/PAYMENT PANEL)
    if (interaction.isStringSelectMenu() && (interaction.customId.startsWith("select_product_") || interaction.customId.startsWith("select_report_") || interaction.customId.startsWith("select_customer_") || interaction.customId.startsWith("select_buy_") || interaction.customId.startsWith("select_key_"))) {
        const value = interaction.values[0];
        if (value === "none" || value === "error") return interaction.reply({ content: "❌ অবৈধ অপশন!", flags: [MessageFlags.Ephemeral] });

        if (value === "generate_1time_key") {
            return handleOneTimeKeyGeneration(interaction);
        }

        let type = ""; let embedColor = ""; let buttonId = "";
        const lowerVal = value.toLowerCase();

        if (interaction.customId === "select_product_ticket") { type = "ticket"; embedColor = "#5865F2"; buttonId = `create_ticket_${lowerVal}`; }
        else if (interaction.customId === "select_report_category") { type = "report"; embedColor = "#ED4245"; buttonId = `create_report_${lowerVal}`; }
        else if (interaction.customId === "select_customer_category") { type = "customer"; embedColor = "#57F287"; buttonId = `create_customer_${lowerVal}`; }
        else if (interaction.customId === "select_buy_category") { type = "order"; embedColor = "#9B59B6"; buttonId = `pay_gateway_${lowerVal}`; } 

        if (type === "order") {
            const category = getNormalizedCategory(lowerVal);
            const userId = interaction.user.id;
            const basePrice = Number(PACKAGE_PRICES[category] || 510);
            const sessionRef = db.ref(`pending_payments/${userId}_${category}`);
            await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
            const newSession = {
                targetPrice: basePrice,
                basePrice,
                appliedCoupon: null,
                appliedDiscount: 0,
                totalPaid: 0,
                usedTxns: [],
                provider: null,
                status: "select_provider",
                createdAt: Date.now(),
                createdByDiscordId: userId
            };
            const sessionResult = await sessionRef.transaction(current => {
                if (current && current.status === "creating") return;
                if (current && current.status !== "completed" && ((Number(current.totalPaid) || 0) > 0 || (Array.isArray(current.usedTxns) && current.usedTxns.length > 0))) return;
                return newSession;
            }, undefined, false);
            if (!sessionResult.committed) {
                return interaction.editReply("⚠️ এই প্যাকেজের একটি পেমেন্ট ইতোমধ্যে প্রক্রিয়াধীন। পুরোনো TxnID/অ্যাকাউন্ট প্রক্রিয়া শেষ না হওয়া পর্যন্ত নতুন checkout শুরু করা যাবে না।");
            }

            let checkoutSession = sessionResult.snapshot.val() || newSession;
            const autoCouponEnabled = await isAutoCouponEnabled(userId).catch(() => true);
            if (autoCouponEnabled) {
                const autoCoupon = await reserveBestAutoCoupon(userId, category, basePrice).catch(err => {
                    console.error("Automatic coupon lookup failed:", err.message);
                    return null;
                });
                if (autoCoupon) {
                    checkoutSession = {
                        ...checkoutSession,
                        targetPrice: Math.max(0, basePrice - autoCoupon.discount),
                        appliedCoupon: autoCoupon.code,
                        appliedDiscount: autoCoupon.discount,
                        autoCouponApplied: true,
                        autoCouponBalanceBefore: autoCoupon.balance,
                        couponAppliedAt: Date.now()
                    };
                    await sessionRef.update(checkoutSession);

                    if (checkoutSession.targetPrice <= 0) {
                        await consumeCouponBalance(autoCoupon.code, userId, category, autoCoupon.discount);
                        checkoutSession = { ...checkoutSession, status: "pending", totalPaid: 0, usedTxns: ["AUTO_COUPON_100_PERCENT_OFF"] };
                        await sessionRef.update(checkoutSession);
                        const freeEmbed = new EmbedBuilder()
                            .setTitle(`🎉 Auto Coupon Applied — ${category.toUpperCase()}`)
                            .setDescription(
                                `🎟️ **কুপন:** \`${autoCoupon.code}\`\n` +
                                `💸 **ব্যবহৃত কুপন ব্যালেন্স:** \`${autoCoupon.discount}\` BDT\n` +
                                `💰 **এখন পরিশোধযোগ্য:** \`0 BDT\`\n\n` +
                                `আপনার কুপন দিয়ে প্যাকেজের পুরো মূল্য কভার হয়েছে। অ্যাকাউন্ট তৈরি করতে নিচের বাটনে চাপ দিন।`
                            ).setColor("Green");
                        const credentialRow = new ActionRowBuilder().addComponents(
                            new ButtonBuilder().setCustomId(`open_cred_modal_${category}`).setLabel("🔑 Create Account Credentials").setStyle(ButtonStyle.Success)
                        );
                        return interaction.editReply({ embeds: [freeEmbed], components: [credentialRow] });
                    }
                }
            }

            const appliedCouponText = checkoutSession.appliedCoupon
                ? `\n🎟️ **Auto Coupon:** \`${checkoutSession.appliedCoupon}\` — \`${checkoutSession.appliedDiscount} BDT\` ছাড়\n💰 **কুপনের পর পরিশোধযোগ্য:** \`${checkoutSession.targetPrice} BDT\``
                : `\n🎟️ **Auto Coupon:** ${autoCouponEnabled ? "ON (যোগ্য কুপন থাকলে নিজে থেকে ব্যবহার হবে)" : "OFF (ম্যানুয়াল কুপন ব্যবহার করা যাবে)"}`;
            const pickerEmbed = new EmbedBuilder()
                .setTitle(`🛍️ ${category.toUpperCase()} — পেমেন্ট মাধ্যম নির্বাচন করুন`)
                .setDescription(
                    `📦 **প্যাকেজ:** \`${category.toUpperCase()}\`\n` +
                    `💰 **প্যাকেজের মূল্য:** \`${basePrice} BDT\`\n` +
                    (checkoutSession.appliedCoupon ? appliedCouponText : `${appliedCouponText}`) + `\n\n` +
                    `bKash অথবা Nagad নির্বাচন করুন। নম্বর দেখানোর আগে bot স্বয়ংক্রিয়ভাবে **ONLINE CHECK** করবে। Reader offline থাকলে কোনো নম্বর দেখানো হবে না।`
                )
                .setColor("Blue");
            const providerRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`pay_provider_bkash_${category}`).setLabel("bKash নির্বাচন করুন").setStyle(ButtonStyle.Primary),
                new ButtonBuilder().setCustomId(`pay_provider_nagad_${category}`).setLabel("Nagad নির্বাচন করুন").setStyle(ButtonStyle.Success)
            );
            const components = [providerRow];
            if (!autoCouponEnabled) {
                components.push(new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`apply_coupon_${category}`).setLabel("🎟️ Coupon Code ব্যবহার করুন").setStyle(ButtonStyle.Secondary)
                ));
            }
            return interaction.editReply({ embeds: [pickerEmbed], components });
        } else if (type) {
            const ephemeralEmbed = new EmbedBuilder().setTitle(`📌 Selected Category: ${value.toUpperCase().replace("_", " ")}`).setDescription(`চ্যানেল তৈরি করতে নিচের বাটনে চাপ দিন।`).setColor(embedColor);
            const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(buttonId).setLabel(`Create ${type.toUpperCase()}`).setStyle(ButtonStyle.Success));
            return interaction.reply({ embeds: [ephemeralEmbed], components: [row], flags: [MessageFlags.Ephemeral] });
        }
    }

    // Modal Submit & Payment Handlers
    if (interaction.isModalSubmit() && interaction.customId.startsWith("modal_coupon_")) {
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
        
        const rawCategory = interaction.customId.split("_")[2].toLowerCase();
        const category = getNormalizedCategory(rawCategory);
        const couponEntered = interaction.fields.getTextInputValue("coupon_code_input").trim().toUpperCase();
        const userId = interaction.user.id;
        
        let basePrice = PACKAGE_PRICES[category] || 510;
        let finalPrice = basePrice;
        let discountText = "কোনো ডিসকাউন্ট কুপন ব্যবহার করা হয়নি।";
        let appliedCouponCode = null;
        let appliedDiscountValue = 0;

        if (couponEntered !== "SKIP") {
            const couponRef = db.ref(`coupons/${couponEntered}`);
            const couponSnap = await couponRef.once("value");

            if (couponSnap.exists()) {
                const couponData = couponSnap.val();
                const now = Date.now();

                if (couponData.userId !== userId) {
                    discountText = "❌ **এই কুপনটি আপনার অ্যাকাউন্টের নয়।** নিজের কুপন কোড ব্যবহার করুন।";
                } else if (couponData.status === "used") {
                    discountText = "❌ **কুপন কোডটি ইতোমধ্যে ব্যবহার করা হয়েছে!** মূল মূল্য প্রযোজ্য হবে।";
                } else if (couponData.expiresAt && couponData.expiresAt < now) {
                    await couponRef.update({ status: "expired" });
                    discountText = "❌ **কুপন কোডটির মেয়াদ শেষ হয়ে গেছে!** মূল মূল্য প্রযোজ্য হবে।";
                } else if (couponData.status === "active") {
                    const reservation = await couponRef.transaction((current) => {
                        const reserveNow = Date.now();
                        if (!current || current.status !== "active" || (current.expiresAt && current.expiresAt < reserveNow)) return;
                        const sameCheckout = current.reservedBy === userId && current.reservedCategory === category;
                        const staleReservation = current.reservedBy && (reserveNow - (Number(current.reservedAt) || 0) >= 30 * 60 * 1000);
                        if (current.reservedBy && !sameCheckout && !staleReservation) return;
                        return {
                            ...current,
                            reservedBy: userId,
                            reservedCategory: category,
                            reservedAt: reserveNow
                        };
                    }, undefined, false);

                    if (!reservation.committed) {
                        discountText = "⚠️ **কুপনটি অন্য একটি চেকআউটে সংরক্ষিত আছে বা আর ব্যবহারযোগ্য নয়।** মূল মূল্য প্রযোজ্য হবে।";
                    } else {
                        const reservedCoupon = reservation.snapshot.val();
                        const couponBalance = getCouponBalance(reservedCoupon);
                        const discount = Math.min(basePrice, couponBalance);
                        if (!Number.isFinite(discount) || discount <= 0) {
                            await couponRef.update({ reservedBy: null, reservedCategory: null, reservedAt: null }).catch(() => {});
                            discountText = "⚠️ **কুপনটির ডিসকাউন্ট ভ্যালু ভুল।** মূল মূল্য প্রযোজ্য হবে।";
                        } else {
                            appliedDiscountValue = discount;
                            finalPrice = Math.max(0, basePrice - appliedDiscountValue);
                            appliedCouponCode = couponEntered;
                            discountText = `🎉 **কুপন কোড \`${couponEntered}\` সফলভাবে অ্যাপ্লাই হয়েছে!**\n` +
                                           `💸 **ছাড়ের পরিমাণ:** \`${appliedDiscountValue}\` ৳\n` +
                                           `🏷️ **নতুন পরিশোধযোগ্য মূল্য:** \`${finalPrice}\` ৳`;
                        }
                    }
                }
            } else {
                discountText = "⚠️ **অবৈধ কুপন কোড!** সিস্টেমের ডেটাবেজে এই কুপন পাওয়া যায়নি। মূল মূল্য প্রযোজ্য হবে।";
            }
        }

        if (finalPrice <= 0) {
            await db.ref(`pending_payments/${userId}_${category}`).set({
                targetPrice: 0,
                basePrice: basePrice,
                appliedCoupon: appliedCouponCode,
                appliedDiscount: appliedDiscountValue,
                totalPaid: 0,
                usedTxns: ["COUPON_100_PERCENT_OFF"],
                status: "pending"
            });

            if (appliedCouponCode) {
                await consumeCouponBalance(appliedCouponCode, userId, category, appliedDiscountValue);
            }

            const zeroPriceEmbed = new EmbedBuilder()
                .setTitle(`🎉 100% Discount Applied! (${category.toUpperCase()})`)
                .setDescription(
                    `📦 **প্যাকেজের রেগুলার মূল্য:** \`${basePrice}\` BDT\n` +
                    `🎁 **কুপন ডিসকাউন্ট:** \`${appliedDiscountValue}\` BDT\n` +
                    `💰 **আপনাকে পেমেন্ট করতে হবে:** \`0\` BDT (সম্পূর্ণ ফ্রি!)\n\n` +
                    `✨ আপনার কুপনের মাধ্যমে পুরো পেমেন্ট সম্পূর্ণ হয়েছে।\n\n` +
                    `👉 অ্যাকাউন্ট তৈরির জন্য নিচের **"Create Account Credentials"** বাটনে ক্লিক করুন।`
                )
                .setColor("#00FF00");

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(`open_cred_modal_${category}`)
                    .setLabel("🔑 Create Account Credentials")
                    .setStyle(ButtonStyle.Success)
            );

            return interaction.editReply({ embeds: [zeroPriceEmbed], components: [row] });
        }

        await db.ref(`pending_payments/${userId}_${category}`).set({
            targetPrice: finalPrice,
            basePrice,
            appliedCoupon: appliedCouponCode,
            appliedDiscount: appliedDiscountValue,
            totalPaid: 0,
            usedTxns: [],
            provider: null,
            status: "select_provider",
            createdAt: Date.now(),
            createdByDiscordId: userId
        });

        const pickerEmbed = new EmbedBuilder()
            .setTitle(`🛍️ ${category.toUpperCase()} — পেমেন্ট মাধ্যম নির্বাচন করুন`)
            .setDescription(
                `📦 **প্যাকেজের রেগুলার মূল্য:** \`${basePrice}\` BDT\n` +
                `💰 **ছাড়ের পর পরিশোধযোগ্য:** \`${finalPrice}\` BDT\n\n` +
                `📱 bKash অথবা Nagad নির্বাচন করুন। নম্বর দেখানোর আগে bot স্বয়ংক্রিয়ভাবে **ONLINE CHECK** করবে। Reader offline থাকলে নম্বর দেখানো হবে না।\n\n` +
                `🎁 **কুপন স্ট্যাটাস:**\n${discountText}`
            )
            .setColor("Blue");
        const providerRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`pay_provider_bkash_${category}`).setLabel("bKash নির্বাচন করুন").setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId(`pay_provider_nagad_${category}`).setLabel("Nagad নির্বাচন করুন").setStyle(ButtonStyle.Success)
        );
        return interaction.editReply({ embeds: [pickerEmbed], components: [providerRow] });
    }

    if (interaction.isButton() && interaction.customId.startsWith("apply_coupon_")) {
        const category = getNormalizedCategory(interaction.customId.slice("apply_coupon_".length));
        const modal = new ModalBuilder().setCustomId(`modal_coupon_${category}`).setTitle("🎟️ Coupon / Discount Code");
        const couponInput = new TextInputBuilder()
            .setCustomId("coupon_code_input")
            .setLabel("কুপন কোড দিন (না থাকলে SKIP লিখুন)")
            .setStyle(TextInputStyle.Short)
            .setValue("SKIP")
            .setRequired(true);
        modal.addComponents(new ActionRowBuilder().addComponents(couponInput));
        return interaction.showModal(modal);
    }

    if (interaction.isButton() && interaction.customId.startsWith("pay_provider_")) {
        const match = /^pay_provider_(bkash|nagad)_(.+)$/.exec(interaction.customId);
        if (!match) return interaction.reply({ content: "❌ Payment option invalid.", flags: [MessageFlags.Ephemeral] });
        const provider = match[1];
        const category = getNormalizedCategory(match[2]);
        const lockKey = `${interaction.user.id}:${category}`;
        if (readerCheckLocks.has(lockKey)) {
            await interaction.deferUpdate().catch(() => {});
            return;
        }
        readerCheckLocks.add(lockKey);
        readerCheckLastAt.set(interaction.user.id, Date.now());
        try {
            await interaction.update({ content: "🟠 **ONLINE CHECK চলছে...** Reader online না হওয়া পর্যন্ত পেমেন্ট নম্বর দেখানো হবে না।", embeds: [], components: [] });
            const sessionRef = db.ref(`pending_payments/${interaction.user.id}_${category}`);
            const sessionSnap = await sessionRef.once("value");
            const session = sessionSnap.val();
            if (!session || session.status !== "select_provider") {
                return interaction.editReply({ content: "⚠️ এই checkout আর নির্বাচনযোগ্য নয়। আবার package নির্বাচন করুন।", embeds: [], components: [] });
            }
            const selected = await sessionRef.transaction(current => {
                if (!current || current.status !== "select_provider") return;
                return { ...current, provider, status: "checking_reader", providerSelectedAt: Date.now(), lastReaderCheckAt: Date.now() };
            }, undefined, false);
            if (!selected.committed) {
                return interaction.editReply({ content: "⚠️ এই checkout-এ আরেকটি payment check চলছে। একই বাটন বারবার চাপার প্রয়োজন নেই।", embeds: [], components: [] });
            }
            const readerState = await getPaymentReaderState();
            const paymentNumber = getPaymentNumber(provider);
            const updatedSession = { ...(selected.snapshot.val() || {}), provider };
            if (readerState.online && paymentNumber) {
                updatedSession.status = "awaiting_txn";
                updatedSession.readerCheckedAt = Date.now();
                updatedSession.readerDeviceUid = readerState.deviceUid;
                updatedSession.numberShownAt = Date.now();
            } else {
                updatedSession.status = readerState.online ? "number_not_configured" : "reader_offline";
                updatedSession.lastReaderCheckAt = Date.now();
            }
            await sessionRef.update(updatedSession);
            const reply = await interaction.editReply({ content: "", ...buildPaymentPage(category, updatedSession, readerState, paymentNumber) });
            if (!readerState.online && TRUSTED_READER_UIDS.size > 0) {
                void autoWatchReaderOnline(interaction, category, sessionRef, provider);
            }
            return reply;
        } catch (err) {
            console.error("Payment provider selection/online check failed:", err);
            return interaction.editReply({ content: "❌ ONLINE CHECK করা যায়নি। নম্বর নিরাপত্তার জন্য লুকানো রাখা হয়েছে। পরে আবার check করুন।", embeds: [], components: [] }).catch(() => {});
        } finally {
            readerCheckLocks.delete(lockKey);
        }
    }

    if (interaction.isButton() && interaction.customId.startsWith("check_reader_")) {
        const category = getNormalizedCategory(interaction.customId.slice("check_reader_".length));
        const lockKey = `${interaction.user.id}:${category}`;
        const now = Date.now();
        const lastCheck = readerCheckLastAt.get(interaction.user.id) || 0;
        if (readerCheckLocks.has(lockKey) || (now - lastCheck) < READER_RECHECK_COOLDOWN_MS) {
            // Acknowledge quietly; repeated clicks do not create extra chat messages or backend checks.
            await interaction.deferUpdate().catch(() => {});
            return;
        }
        readerCheckLocks.add(lockKey);
        try {
            await interaction.deferUpdate();
            const sessionRef = db.ref(`pending_payments/${interaction.user.id}_${category}`);
            const snap = await sessionRef.once("value");
            const session = snap.val();
            if (!session || !["reader_offline", "number_not_configured", "awaiting_txn", "pending"].includes(session.status) || !["bkash", "nagad"].includes(String(session.provider || ""))) {
                return interaction.editReply({ content: "❌ সক্রিয় payment session পাওয়া যায়নি। Shop থেকে package নির্বাচন করুন।", embeds: [], components: [] });
            }
            const storedCheckAt = Number(session.lastReaderCheckAt) || 0;
            if (storedCheckAt > 0 && (now - storedCheckAt) < READER_RECHECK_COOLDOWN_MS) {
                // Persisted cooldown also survives a bot restart; do not message-spam the user.
                readerCheckLastAt.set(interaction.user.id, storedCheckAt);
                return;
            }
            readerCheckLastAt.set(interaction.user.id, now);
            await interaction.editReply({ content: "🟠 **ONLINE CHECK চলছে...** একই সময়ে আরেকটি check request প্রয়োজন নেই।", embeds: [], components: [] });
            const readerState = await getPaymentReaderState();
            const paymentNumber = getPaymentNumber(session.provider);
            const updatedSession = { ...session, lastReaderCheckAt: Date.now() };
            if (readerState.online && paymentNumber) {
                updatedSession.status = "awaiting_txn";
                updatedSession.readerCheckedAt = Date.now();
                updatedSession.readerDeviceUid = readerState.deviceUid;
                updatedSession.numberShownAt = updatedSession.numberShownAt || Date.now();
            } else {
                updatedSession.status = readerState.online ? "number_not_configured" : "reader_offline";
            }
            await sessionRef.update(updatedSession);
            return interaction.editReply({ content: "", ...buildPaymentPage(category, updatedSession, readerState, paymentNumber) });
        } catch (err) {
            console.error("Reader recheck failed:", err);
            return interaction.editReply({ content: "❌ ONLINE CHECK আপাতত ব্যর্থ হয়েছে। নম্বর দেখানো হয়নি।", embeds: [], components: [] }).catch(() => {});
        } finally {
            readerCheckLocks.delete(lockKey);
        }
    }

    if (interaction.isButton() && interaction.customId.startsWith("submit_txn_")) {
        const rawCategory = interaction.customId.slice("submit_txn_".length).toLowerCase();
        const category = getNormalizedCategory(rawCategory);
        // Session/provider/numberShownAt is checked after modal submit, avoiding a slow pre-modal DB call.
        const modal = new ModalBuilder()
            .setCustomId(`modal_txn_${category}`)
            .setTitle("🔒 Submit Transaction ID");

        const txnInput = new TextInputBuilder()
            .setCustomId("txn_id_input")
            .setLabel("Transaction ID (TxnID)")
            .setPlaceholder("e.g. A1B2C3D4E5")
            .setStyle(TextInputStyle.Short)
            .setRequired(true);

        modal.addComponents(new ActionRowBuilder().addComponents(txnInput));
        return interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith("modal_txn_")) {
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

        const rawCategory = interaction.customId.split("_")[2].toLowerCase();
        const category = getNormalizedCategory(rawCategory);
        const txnId = interaction.fields.getTextInputValue("txn_id_input").trim().toUpperCase();
        const userId = interaction.user.id;
        if (!/^[A-Z0-9_-]{3,64}$/.test(txnId)) {
            return interaction.editReply("❌ Transaction ID-তে অবৈধ অক্ষর আছে। শুধু ইংরেজি অক্ষর, সংখ্যা, _ বা - ব্যবহার করুন (৩–৬৪ অক্ষর)।");
        }
        const txnLockKey = `${userId}:${category}`;
        if (paymentTxnLocks.has(txnLockKey)) {
            return interaction.editReply("⏳ আপনার TxnID ইতোমধ্যে যাচাই হচ্ছে। একই সময়ে আবার submit করার প্রয়োজন নেই।");
        }
        const previousTxnSubmitAt = paymentTxnLastAt.get(txnLockKey) || 0;
        const cooldownRemaining = PAYMENT_TXN_SUBMIT_COOLDOWN_MS - (Date.now() - previousTxnSubmitAt);
        if (cooldownRemaining > 0) {
            return interaction.editReply(`🛡️ Spam protection: আবার TxnID submit করার আগে ${Math.ceil(cooldownRemaining / 1000)} সেকেন্ড অপেক্ষা করুন।`);
        }
        paymentTxnLocks.add(txnLockKey);
        paymentTxnLastAt.set(txnLockKey, Date.now());

        const sessionRef = db.ref(`pending_payments/${userId}_${category}`);
        let txnRef = null;
        let claimedTxnAt = null;
        let paymentRecorded = false;

        try {
            const sessionSnap = await sessionRef.once("value");
            if (!sessionSnap.exists()) return interaction.editReply("❌ কোনো payment session পাওয়া যায়নি। Shop থেকে package নির্বাচন করুন।");
            const initialSession = sessionSnap.val() || {};
            if (["creating", "completed"].includes(initialSession.status)) {
                return interaction.editReply("⚠️ এই payment session ইতোমধ্যে ব্যবহার হচ্ছে বা সম্পন্ন হয়েছে।");
            }
            if (!initialSession.provider || !initialSession.numberShownAt || !["bkash", "nagad"].includes(String(initialSession.provider))) {
                return interaction.editReply("🟠 ONLINE CHECK সম্পন্ন নয়। নম্বর দেখানোর আগে Reader status যাচাই করতে হবে।");
            }
            if (TRUSTED_READER_UIDS.size === 0) {
                return interaction.editReply("🔴 Payment Reader trusted device configure করা হয়নি। তাই TxnID স্বয়ংক্রিয়ভাবে verify করা যাচ্ছে না।");
            }

            const readerMatch = await waitForTrustedReaderEvent(txnId);
            if (!readerMatch) {
                return interaction.editReply("⏳ এই TxnID trusted Payment Reader-এ এখনো পাওয়া যায়নি। bKash/Nagad notification আসা ও upload হওয়া পর্যন্ত অপেক্ষা করে একই TxnID আবার submit করুন।");
            }
            const event = readerMatch.event || {};
            const selectedProvider = String(initialSession.provider).toLowerCase();
            const eventProvider = String(event.provider || "").toLowerCase();
            if (eventProvider !== selectedProvider) {
                return interaction.editReply(`❌ Provider mismatch: আপনি ${getProviderLabel(selectedProvider)} নির্বাচন করেছেন, কিন্তু Reader event ${getProviderLabel(eventProvider)} থেকে এসেছে। সঠিক payment মাধ্যম নির্বাচন করুন।`);
            }
            const eventAmount = Number(event.amount);
            if (!Number.isFinite(eventAmount) || eventAmount <= 0) {
                return interaction.editReply("⏳ Reader TxnID পেয়েছে, কিন্তু notification থেকে amount পড়তে পারেনি। স্বয়ংক্রিয়ভাবে credit করা যাবে না।");
            }
            const capturedAt = Number(event.capturedAt);
            const notificationPostedAt = Number(event.notificationPostedAt) || capturedAt;
            if (!Number.isFinite(capturedAt) || !Number.isFinite(notificationPostedAt) ||
                notificationPostedAt < (Number(initialSession.createdAt) || 0)) {
                return interaction.editReply("❌ এই TxnID checkout শুরু হওয়ার আগের notification। পুরোনো transaction দিয়ে নতুন package কেনা যাবে না।");
            }

            txnRef = db.ref(`transactions/${txnId}`);
            let txnSnap = await txnRef.once("value");
            if (!txnSnap.exists()) {
                await txnRef.transaction(current => {
                    if (current !== null) return;
                    return {
                        transactionId: txnId,
                        provider: selectedProvider,
                        amount: eventAmount,
                        currency: "BDT",
                        used: false,
                        verificationStatus: "verified",
                        verificationSource: "trusted_reader_notification",
                        verifiedByReaderUid: readerMatch.uid,
                        readerEventKey: readerMatch.eventKey,
                        eventCapturedAt: capturedAt,
                        notificationPostedAt,
                        verifiedAt: Date.now()
                    };
                }, undefined, false);
                txnSnap = await txnRef.once("value");
            }
            const txnData = txnSnap.val() || {};
            const verificationSource = String(txnData.verificationSource || "").toLowerCase();
            if (String(txnData.verificationStatus || "").toLowerCase() !== "verified" ||
                !["trusted_reader_notification", "official_api"].includes(verificationSource)) {
                return interaction.editReply("⏳ TxnID record আছে, কিন্তু trusted Reader/official API verified status নেই। Payment credit করা হয়নি।");
            }
            if (String(txnData.provider || "").toLowerCase() !== selectedProvider) {
                return interaction.editReply("❌ এই TxnID-র provider checkout-এর সঙ্গে মেলেনি। Payment credit করা হয়নি।");
            }
            if (txnData.used === true) return interaction.editReply("🚫 **Duplicate Transaction!** এই Transaction ID আগেই ব্যবহার করা হয়েছে।");
            const listedAmount = Number(txnData.amount);
            if (!Number.isFinite(listedAmount) || listedAmount <= 0 || Math.abs(listedAmount - eventAmount) > 0.009) {
                return interaction.editReply("❌ Transaction amount validation ব্যর্থ হয়েছে। Payment credit করা হয়নি।");
            }

            const now = Date.now();
            claimedTxnAt = now;
            // A transaction prevents two users from claiming the same TxnID at once.
            const claimResult = await txnRef.transaction((current) => {
                if (!current || current.used === true) return;
                const amount = Number(current.amount);
                if (!Number.isFinite(amount) || amount <= 0) return;
                return { ...current, used: true, usedBy: userId, usedAt: claimedTxnAt };
            }, undefined, false);
            if (!claimResult.committed) {
                return interaction.editReply("🚫 **Duplicate Transaction!** এই Transaction ID ইতোমধ্যে অন্য একটি রিকোয়েস্ট ব্যবহার করেছে।");
            }

            const newTxnAmount = Number(claimResult.snapshot.val()?.amount);
            if (!Number.isFinite(newTxnAmount) || newTxnAmount <= 0) {
                await txnRef.transaction(current => current?.usedBy === userId && current?.usedAt === claimedTxnAt ? { ...current, used: false, usedBy: null, usedAt: null } : undefined, undefined, false);
                return interaction.editReply("❌ Transaction amount invalid. অ্যাডমিনের সাহায্য নিন।");
            }

            let sessionResult;
            sessionResult = await sessionRef.transaction((current) => {
                if (!current || ["creating", "completed"].includes(current.status)) return;
                const target = Number(current.targetPrice);
                const alreadyPaid = Number(current.totalPaid) || 0;
                if (!Number.isFinite(target) || target < 0 || alreadyPaid >= target) return;
                const used = Array.isArray(current.usedTxns) ? current.usedTxns : [];
                if (used.includes(txnId)) return;
                return {
                    ...current,
                    category,
                    targetPrice: target,
                    totalPaid: alreadyPaid + newTxnAmount,
                    usedTxns: [...used, txnId],
                    status: "pending",
                    lastUpdated: Date.now()
                };
            }, undefined, false);

            if (!sessionResult.committed) {
                // The session changed before the TxnID could be applied; release this claim safely.
                await txnRef.transaction(current => current?.usedBy === userId && current?.usedAt === claimedTxnAt ? { ...current, used: false, usedBy: null, usedAt: null } : undefined, undefined, false);
                return interaction.editReply("⚠️ পেমেন্ট সেশনটি ইতোমধ্যে আপডেট হয়েছে। সেশনটি রিফ্রেশ করে আবার চেষ্টা করুন।");
            }

            const sessionData = sessionResult.snapshot.val() || {};
            const targetPrice = Number(sessionData.targetPrice);
            const currentTotalPaid = Number(sessionData.totalPaid) || 0;
            const usedTxns = Array.isArray(sessionData.usedTxns) ? sessionData.usedTxns : [];
            paymentRecorded = currentTotalPaid >= targetPrice;
            if (currentTotalPaid < targetPrice) {
                const remainingDue = targetPrice - currentTotalPaid;
                const readerState = await getPaymentReaderState();
                const paymentNumber = getPaymentNumber(sessionData.provider);
                const nextPage = buildPaymentPage(category, sessionData, readerState, paymentNumber);
                return interaction.editReply({
                    content: `⏳ আংশিক পেমেন্ট পাওয়া গেছে। প্রয়োজনীয় মূল্য: ${targetPrice} BDT; মোট পাওয়া: ${currentTotalPaid} BDT; বকেয়া: ${remainingDue} BDT.`,
                    ...nextPage
                });
            }

            let extraPayment = currentTotalPaid - targetPrice;
            let createdCouponCode = null;

            if (extraPayment > 0) {
                const newCouponObj = {
                    userId,
                    username: interaction.user.username,
                    couponValue: extraPayment,
                    remainingValue: extraPayment,
                    extraPaymentAmount: extraPayment,
                    createdAt: Date.now(),
                    expiresAt: Date.now() + (90 * 24 * 60 * 60 * 1000),
                    status: "active"
                };

                // Bounded, atomic allocation prevents an infinite collision loop or accidental overwrite.
                for (let attempt = 0; attempt < 10 && !createdCouponCode; attempt++) {
                    const candidate = generateUniqueCouponCode();
                    const couponCreate = await db.ref(`coupons/${candidate}`).transaction(
                        current => current === null ? { ...newCouponObj, couponCode: candidate } : undefined,
                        undefined,
                        false
                    );
                    if (couponCreate.committed) createdCouponCode = candidate;
                }
                if (!createdCouponCode) console.error("❌ Could not allocate a unique extra-payment coupon.");
            }

            if (sessionData.appliedCoupon) {
                const couponConsumption = await consumeCouponBalance(
                    sessionData.appliedCoupon,
                    userId,
                    category,
                    Number(sessionData.appliedDiscount) || 0
                );
                if (!couponConsumption.committed) {
                    console.warn("Coupon balance could not be consumed after successful payment:", sessionData.appliedCoupon);
                }
            }

            let extraInfoText = "";
            if (extraPayment > 0 && createdCouponCode) {
                extraInfoText = `\n\n🎁 **Extra Payment Reward Coupon Generated!**\n` +
                                `আপনি প্যাকেজের মূল্যের চেয়ে **${extraPayment} ৳** বেশি পরিশোধ করেছেন।\n` +
                                `আপনার জন্য একটি ডিসকাউন্ট কুপন তৈরি করা হয়েছে:\n` +
                                `🎟️ **Coupon Code:** \`${createdCouponCode}\`\n` +
                                `💸 **Discount Balance:** \`${extraPayment}\` ৳\n` +
                                `📌 **Status:** Active`;
            }

            const successPayEmbed = new EmbedBuilder()
                .setTitle("✅ Payment Successfully Verified!")
                .setDescription(
                    `আপনার পেমেন্ট সফলভাবে ভেরিফাই করা হয়েছে।\n\n` +
                    `💰 **মোট পরিশোধিত:** \`${currentTotalPaid}\` BDT\n` +
                    `📦 **প্যাকেজ:** \`${category.toUpperCase()}\`${extraInfoText}\n\n` +
                    `👉 অ্যাকাউন্ট তৈরির জন্য নিচের **"Create Account Credentials"** বাটনে ক্লিক করুন।`
                )
                .setColor("Green");

            const createAccRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(`open_cred_modal_${category}`)
                    .setLabel("🔑 Create Account Credentials")
                    .setStyle(ButtonStyle.Success)
            );

            return interaction.editReply({ embeds: [successPayEmbed], components: [createAccRow] });

        } catch (err) {
            console.error("❌ Txn Verification Error:", err);
            if (paymentRecorded) {
                const createAccRow = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId(`open_cred_modal_${category}`)
                        .setLabel("🔑 Create Account Credentials")
                        .setStyle(ButtonStyle.Success)
                );
                return interaction.editReply({
                    content: "✅ পেমেন্ট রেকর্ড হয়েছে। অতিরিক্ত কুপন/নোটিফিকেশন তৈরি করতে সমস্যা হয়েছে, তবে অ্যাকাউন্ট তৈরি করতে নিচের বাটন ব্যবহার করুন।",
                    components: [createAccRow]
                });
            }
            return interaction.editReply("❌ **পেমেন্ট প্রক্রিয়াকরণে সমস্যা হয়েছে!** অনুগ্রহ করে পরে আবার চেষ্টা করুন।");
        } finally {
            paymentTxnLocks.delete(txnLockKey);
        }
    }

    if (interaction.isButton() && interaction.customId.startsWith("open_cred_modal_")) {
        const rawCategory = interaction.customId.split("_")[3].toLowerCase();
        const category = getNormalizedCategory(rawCategory);

        const modal = new ModalBuilder()
            .setCustomId(`modal_create_account_${category}`)
            .setTitle("👤 Create Your Custom Account");

        const userInput = new TextInputBuilder()
            .setCustomId("custom_username")
            .setLabel("Username (৩–২০ অক্ষর, ইংরেজি/সংখ্যা/_)")
            .setStyle(TextInputStyle.Short)
            .setMinLength(3)
            .setMaxLength(20)
            .setRequired(true);

        const passInput = new TextInputBuilder()
            .setCustomId("custom_password")
            .setLabel("Password (৮–১২৮ অক্ষর)")
            .setStyle(TextInputStyle.Short)
            .setMinLength(8)
            .setMaxLength(128)
            .setRequired(true);

        modal.addComponents(
            new ActionRowBuilder().addComponents(userInput),
            new ActionRowBuilder().addComponents(passInput)
        );

        return interaction.showModal(modal);
    }

    // 🌟 FULL AUTOMATED ACCOUNT CREATION & SYNC FOR C++ APP
    if (interaction.isModalSubmit() && interaction.customId.startsWith("modal_create_account_")) {
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

        const rawCategory = interaction.customId.split("_")[3].toLowerCase();
        const category = getNormalizedCategory(rawCategory);

        const customUser = interaction.fields.getTextInputValue("custom_username").trim().toLowerCase();
        const customPass = interaction.fields.getTextInputValue("custom_password");
        const userId = interaction.user.id;
        const userAvatarUrl = interaction.user.displayAvatarURL({ extension: "png", size: 512 });
        const serverName = interaction.guild?.name || "Discord Server";
        const sessionRef = db.ref(`pending_payments/${userId}_${category}`);
        let sessionClaimed = false;
        let accountSaved = false;

        if (!/^[a-z0-9_]{3,20}$/.test(customUser)) {
            return interaction.editReply("❌ Username ৩–২০ অক্ষরের হতে হবে এবং শুধু a-z, 0-9 ও underscore (_) ব্যবহার করা যাবে।");
        }
        if (customPass.length < 8 || customPass.length > 128 || !customPass.trim()) {
            return interaction.editReply("❌ Password ৮–১২৮ অক্ষরের হতে হবে।");
        }

        try {
            const sessionSnap = await sessionRef.once("value");
            const initialSession = sessionSnap.val();
            if (!initialSession || Number(initialSession.totalPaid) < Number(initialSession.targetPrice)) {
                return interaction.editReply("❌ **পেমেন্ট অসম্পূর্ণ!** সম্পূর্ণ টাকা পরিশোধ করুন।");
            }
            if (["creating", "completed"].includes(initialSession.status)) {
                return interaction.editReply("⚠️ এই পেমেন্ট সেশন ইতোমধ্যে ব্যবহার করা হচ্ছে বা অ্যাকাউন্ট তৈরি হয়ে গেছে। একই পেমেন্ট দিয়ে দ্বিতীয় অ্যাকাউন্ট তৈরি করা যাবে না।");
            }

            // Atomically reserve this paid checkout so repeated button/modal submissions cannot create multiple accounts.
            const claimResult = await sessionRef.transaction((current) => {
                if (!current || ["creating", "completed"].includes(current.status)) return;
                const paid = Number(current.totalPaid) || 0;
                const target = Number(current.targetPrice);
                if (!Number.isFinite(target) || target < 0 || paid < target) return;
                return { ...current, status: "creating", creationOwner: userId, creationStartedAt: Date.now() };
            }, undefined, false);

            if (!claimResult.committed) {
                return interaction.editReply("⚠️ এই পেমেন্ট সেশনটি ইতোমধ্যে ব্যবহার করা হয়েছে বা আপডেট হয়েছে।");
            }
            sessionClaimed = true;
            const sessionData = claimResult.snapshot.val() || {};

            let days = 7;
            let packageName = "Weekly";
            if (category === "monthly") {
                days = 30;
                packageName = "Monthly";
            } else if (category === "2_months") {
                days = 60;
                packageName = "2 Months";
            }

            const now = Date.now();
            const expiryTimestamp = now + (days * 24 * 60 * 60 * 1000);
            const userRef = db.ref(`users/${customUser}`);
            const newAccountData = {
                username: customUser,
                // NOTE: The current C++ app schema expects this field. Migrate both apps together to password hashes.
                password: customPass,
                discordId: userId,
                avatarUrl: userAvatarUrl,
                serverName,
                category,
                package: packageName,
                paidAmount: Number(sessionData.totalPaid) || 0,
                usedTxns: Array.isArray(sessionData.usedTxns) ? sessionData.usedTxns : [],
                createdAt: now,
                expiresAt: expiryTimestamp,
                status: "active"
            };

            // Username creation is atomic; an active username cannot be overwritten by a simultaneous request.
            const userClaim = await userRef.transaction((current) => {
                if (!current) return newAccountData;
                const currentExpiry = Number(current.expiresAt);
                if (Number.isFinite(currentExpiry) && currentExpiry <= Date.now()) return newAccountData;
                return;
            }, undefined, false);

            if (!userClaim.committed) {
                await sessionRef.transaction((current) => current?.status === "creating" && current?.creationOwner === userId
                    ? { ...current, status: "pending", creationOwner: null, creationStartedAt: null }
                    : undefined, undefined, false);
                sessionClaimed = false;
                return interaction.editReply(`❌ **Username Already Exists!** \`${customUser}\` নামটি অন্য কারো ব্যবহৃত।`);
            }

            accountSaved = true;
            await sessionRef.update({
                status: "completed",
                accountUsername: customUser,
                completedAt: Date.now(),
                creationOwner: null,
                creationStartedAt: null
            });

            const randomCode = Math.floor(1000 + Math.random() * 9000);
            let supportRoleId = ROLES.SUPPORT_CUSTOMER;
            let channelPrefix = `order-${randomCode}`;

            const permissionOverwrites = [
                { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                { id: VERIFIED_ROLE_ID, deny: [PermissionFlagsBits.ViewChannel] },
                { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] }
            ];

            if (interaction.guild.roles.cache.has(supportRoleId)) permissionOverwrites.push({ id: supportRoleId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });
            if (interaction.guild.roles.cache.has(ROLES.ADMIN)) permissionOverwrites.push({ id: ROLES.ADMIN, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });

            const privateChannel = await interaction.guild.channels.create({
                name: channelPrefix,
                type: 0,
                permissionOverwrites
            });

            const orderEmbed = new EmbedBuilder()
                .setTitle(`🛍️ NEW MEMBERSHIP ORDER CONFIRMED`)
                .setColor("#00FF00")
                .setThumbnail(userAvatarUrl)
                .addFields(
                    { name: "👤 কাস্টমার", value: `${interaction.user}`, inline: true },
                    { name: "📦 প্যাকেজ", value: `\`${packageName.toUpperCase()}\``, inline: true },
                    { name: "👤 Username", value: `\`${customUser}\``, inline: true },
                    { name: "💳 Total Paid", value: `\`${sessionData.totalPaid}\` BDT`, inline: true },
                    { name: "📅 এক্সপায়ার ডেট", value: `<t:${Math.floor(expiryTimestamp / 1000)}:R>`, inline: true }
                )
                .setTimestamp();

            const actionRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`claim_order`).setLabel("🛟 Claim").setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId(`close_order`).setLabel("🔒 Close").setStyle(ButtonStyle.Secondary)
            );

            await privateChannel.send({ content: `${interaction.user} <@&${supportRoleId}>`, embeds: [orderEmbed], components: [actionRow] });

            try {
                const dmEmbed = new EmbedBuilder()
                    .setTitle("🎉 Your Membership Account is Ready!")
                    .setDescription(
                        `👤 **Username:** \`${customUser}\`\n` +
                        `🔑 **Password:** \`${customPass}\`\n` +
                        `📦 **Package:** \`${packageName}\`\n` +
                        `📅 **মেয়াদ:** <t:${Math.floor(expiryTimestamp / 1000)}:R>`
                    )
                    .setThumbnail(userAvatarUrl)
                    .setColor("Green")
                    .setTimestamp();

                await interaction.user.send({ embeds: [dmEmbed] });
            } catch (dmErr) {}

            const trackingChannel = interaction.guild.channels.cache.get(ORDER_TRACKING_CHANNEL_ID);
            if (trackingChannel) {
                const trackingEmbed = buildOrderStatusEmbed(interaction.user, category, privateChannel, "approved", null, null, sessionData.usedTxns ? sessionData.usedTxns.join(", ") : null);
                trackingEmbed.addFields(
                    { name: "👤 Registered Username", value: `\`${customUser}\``, inline: true },
                    { name: "💰 Total Paid Amount", value: `\`${sessionData.totalPaid}\` BDT`, inline: true }
                );

                const trackingMsg = await trackingChannel.send({ embeds: [trackingEmbed] }).catch(() => {});
                if (trackingMsg) {
                    saveOrderLog(privateChannel.id, trackingMsg.id, {
                        userId: interaction.user.id,
                        category: category,
                        status: "approved",
                        txnId: sessionData.usedTxns ? sessionData.usedTxns.join(", ") : "",
                        username: customUser
                    });
                }
            }

            return interaction.editReply({
                content: `✅ **পেমেন্ট সফলভাবে ভেরিফাই হয়েছে!**\n` +
                         `আপনার কাস্টম অ্যাকাউন্ট তৈরি সম্পন্ন হয়েছে: ${privateChannel}`
            });

        } catch (err) {
            console.error("❌ Account Creation Error:", err);
            if (sessionClaimed) {
                try {
                    if (accountSaved) {
                        await sessionRef.update({ status: "completed", accountUsername: customUser, completedAt: Date.now(), creationOwner: null, creationStartedAt: null });
                    } else {
                        await sessionRef.transaction((current) => current?.status === "creating" && current?.creationOwner === userId
                            ? { ...current, status: "pending", creationOwner: null, creationStartedAt: null }
                            : undefined, undefined, false);
                    }
                } catch (reservationErr) {
                    console.error("❌ Could not finalize/release account-creation reservation:", reservationErr.message);
                }
            }
            const message = accountSaved
                ? "⚠️ অ্যাকাউন্টটি Firebase-এ তৈরি হয়েছে, কিন্তু Discord order channel তৈরি/আপডেট করতে সমস্যা হয়েছে। নতুন করে পেমেন্ট বা অ্যাকাউন্ট তৈরি করবেন না; অ্যাডমিনকে জানান।"
                : "❌ **অ্যাকাউন্ট তৈরিতে ত্রুটি ঘটেছে!** সেশন রিলিজ করা হয়েছে; কিছুক্ষণ পর আবার চেষ্টা করুন।";
            return interaction.editReply(message);
        }
    }

    if (interaction.isButton() && interaction.customId.startsWith("create_")) {
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
        const parts = interaction.customId.split("_");
        const type = parts[1]; const category = parts.slice(2).join("_");

        const randomCode = Math.floor(1000 + Math.random() * 9000);
        let supportRoleId = ROLES.SUPPORT_TICKET_REPORT;
        let channelPrefix = `${type}-${randomCode}`;

        if (type === "customer") supportRoleId = ROLES.SUPPORT_CUSTOMER;

        const permissionOverwrites = [
            { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
            { id: VERIFIED_ROLE_ID, deny: [PermissionFlagsBits.ViewChannel] },
            { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] }
        ];

        if (interaction.guild.roles.cache.has(supportRoleId)) permissionOverwrites.push({ id: supportRoleId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });
        if (interaction.guild.roles.cache.has(ROLES.ADMIN)) permissionOverwrites.push({ id: ROLES.ADMIN, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });

        const privateChannel = await interaction.guild.channels.create({
            name: channelPrefix,
            type: 0,
            permissionOverwrites
        });

        const panelEmbed = new EmbedBuilder().setTitle(`🛠️ ${type.toUpperCase()} REQUEST - ${category.toUpperCase().replace("_", " ")}`).setDescription(`স্বাগতম ${interaction.user}!\nআমাদের সাপোর্ট স্টাফ খুব শীঘ্রই আপনাকে সহায়তা করবে।`).setColor("Green").setTimestamp();
        const actionRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`claim_${type}`).setLabel("🛟 Claim").setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId(`close_${type}`).setLabel("🔒 Close").setStyle(ButtonStyle.Secondary)
        );

        await privateChannel.send({ content: `${interaction.user} <@&${supportRoleId}>`, embeds: [panelEmbed], components: [actionRow] });

        const trackingChannel = interaction.guild.channels.cache.get(ORDER_TRACKING_CHANNEL_ID);
        if (trackingChannel) {
            const trackingEmbed = buildOrderStatusEmbed(interaction.user, category, privateChannel, "pending");
            const trackingMsg = await trackingChannel.send({ embeds: [trackingEmbed] }).catch(() => {});
            if (trackingMsg) {
                saveOrderLog(privateChannel.id, trackingMsg.id, {
                    userId: interaction.user.id,
                    category: category,
                    status: "pending"
                });
            }
        }

        return interaction.editReply(`✅ সফলভাবে তৈরি হয়েছে: ${privateChannel}`);
    }

    if (interaction.isButton() && interaction.customId.startsWith("claim_")) {
        const type = interaction.customId.split("_")[1];
        let reqRole = (type === "customer" || type === "order") ? ROLES.SUPPORT_CUSTOMER : ROLES.SUPPORT_TICKET_REPORT;
        if (!interaction.member.roles.cache.has(reqRole) && !interaction.member.roles.cache.has(ROLES.ADMIN)) return interaction.reply({ content: "❌ পারমিশন নেই!", flags: [MessageFlags.Ephemeral] });
        
        await interaction.channel.permissionOverwrites.edit(interaction.user.id, { ViewChannel: true, SendMessages: true }).catch(() => {});
        await interaction.reply({ content: `🛟 এই চ্যানেলটি এখন থেকে স্টাফ ${interaction.user} হ্যান্ডেল করছেন।` });

        db.ref(`staff_duty/${interaction.user.id}/claims`).transaction(c => (c || 0) + 1);
        return;
    }

    if (interaction.isButton() && interaction.customId.startsWith("close_")) {
        const orderLogs = getOrderLogs();
        const currentOrder = orderLogs[interaction.channel.id];
        const member = interaction.member;
        const isAdmin = Boolean(member?.permissions?.has(PermissionFlagsBits.Administrator) || member?.roles?.cache?.has(ROLES.ADMIN));
        const isSupport = Boolean(member?.roles?.cache?.has(ROLES.SUPPORT_TICKET_REPORT) || member?.roles?.cache?.has(ROLES.SUPPORT_CUSTOMER));
        const isTicketOwner = Boolean(
            (currentOrder?.userId && currentOrder.userId === interaction.user.id) ||
            interaction.channel.permissionOverwrites?.cache?.has(interaction.user.id)
        );

        if (!isAdmin && !isSupport && !isTicketOwner) {
            return interaction.reply({ content: "❌ এই টিকিট বন্ধ করার অনুমতি আপনার নেই।", flags: [MessageFlags.Ephemeral] });
        }

        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
        let transcriptSaved = false;
        try {
            const transcript = await discordTranscripts.createTranscript(interaction.channel, {
                limit: -1,
                returnType: "attachment",
                filename: `${interaction.channel.name}-transcript.html`,
                saveImages: true,
                poweredBy: false
            });
            const transcriptLogChan = interaction.guild.channels.cache.get(TRANSCRIPT_LOG_CHANNEL_ID);
            if (transcriptLogChan) {
                await transcriptLogChan.send({
                    content: `📜 **Transcript Log:** #${interaction.channel.name} | Closed by ${interaction.user}`,
                    files: [transcript]
                });
                transcriptSaved = true;
            }
        } catch (tErr) {
            console.error("❌ Transcript creation/upload failed:", tErr.message);
        }

        if (currentOrder?.trackingMessageId) {
            try {
                const trackingChannel = interaction.guild.channels.cache.get(ORDER_TRACKING_CHANNEL_ID);
                const trackingMessage = trackingChannel ? await trackingChannel.messages.fetch(currentOrder.trackingMessageId) : null;
                if (trackingMessage) {
                    const statusEmbed = buildOrderStatusEmbed(
                        `<@${currentOrder.userId || interaction.user.id}>`,
                        currentOrder.category || "unknown",
                        interaction.channel,
                        "closed",
                        interaction.user,
                        null,
                        currentOrder.txnId || null
                    );
                    await trackingMessage.edit({ embeds: [statusEmbed] });
                }
                saveOrderLog(interaction.channel.id, currentOrder.trackingMessageId, {
                    ...currentOrder,
                    status: "closed",
                    closedBy: interaction.user.id,
                    closedAt: Date.now(),
                    transcriptSaved
                });
            } catch (trackingErr) {
                console.error("❌ Order tracking close update failed:", trackingErr.message);
            }
        }

        await interaction.editReply("🔒 চ্যানেলটি ৫ সেকেন্ডের মধ্যে ডিলিট হবে।");
        setTimeout(async () => {
            await interaction.channel.delete().catch(() => {});
        }, 5000);
    }
    } catch (error) {
        console.error("❌ Interaction handler failed:", error);
        const payload = { content: "❌ অনুরোধটি সম্পন্ন করা যায়নি। আবার চেষ্টা করুন বা অ্যাডমিনকে জানান।", flags: [MessageFlags.Ephemeral] };
        try {
            if (interaction.deferred) await interaction.editReply({ content: payload.content });
            else if (interaction.replied) await interaction.followUp(payload);
            else await interaction.reply(payload);
        } catch (replyError) {
            console.error("❌ Could not send interaction error response:", replyError.message);
        }
    }
});

// ================================
// ⚡ PART 4 - Live UI Panels Templates
// ================================

async function getDynamicOrderGuidePanel() {
    const { customDescription, customImage, fullData } = await fetchFirebasePanelData("order_guide");
    const defaultTitle = "📦 HOW TO ORDER & SYSTEM GUIDE";
    const defaultDesc = `🛒 **আমাদের সার্ভার থেকে অর্ডার করার নিয়মাবলী** 🛒`;

    const embed = new EmbedBuilder()
        .setTitle(fullData.title || defaultTitle)
        .setDescription(customDescription || defaultDesc)
        .setColor("#FFAA00")
        .setTimestamp()
        .setFooter({ text: "Order Guide System", iconURL: client.user.displayAvatarURL() });

    if (customImage) embed.setImage(customImage);
    return { embeds: [embed] };
}

// 🌟 সাধারণ টিকিট সাপোর্ট প্যানেল
async function getDynamicTicketPanel() {
    const { options, customDescription, customImage, fullData } = await fetchFirebasePanelData("ticket");
    const defaultDesc = `🎟️ **আমাদের অফিসিয়াল সাপোর্ট প্যানেল** 🎟️\n\nযে কোনো সমস্যা বা অনুসন্ধানের জন্য নিচের ড্রপডাউন সিলেক্ট করুন।`;

    const embed = new EmbedBuilder()
        .setTitle(fullData.title || "🎫 OFFICIAL SUPPORT PANEL")
        .setDescription(customDescription || defaultDesc)
        .setImage(customImage || COVER_IMAGES.TICKET)
        .setColor("#5865F2")
        .setFooter({ text: "Official Support Panel", iconURL: client.user.displayAvatarURL() });

    let finalOptions = options;
    if (options.length === 0 || (options.length === 1 && options[0].value === "none")) {
        finalOptions = [
            {
                label: "💬 General Support Ticket",
                description: "সাধারণ সহায়তার জন্য টিকেট খুলুন",
                value: "general_support"
            }
        ];
    }

    const menu = new StringSelectMenuBuilder()
        .setCustomId("select_product_ticket")
        .setPlaceholder("👇 ড্রপডাউন মেনু থেকে সহায়তার ক্যাটাগরি সিলেক্ট করুন...")
        .addOptions(finalOptions);

    return { embeds: [embed], components: [new ActionRowBuilder().addComponents(menu)] };
}

// 🔑 ১-টাইম কী জেনারেটর প্যানেল
async function getDynamicOneTimeKeyPanel() {
    const { options, customDescription, customImage, fullData } = await fetchFirebasePanelData("onetime_key");
    const defaultDesc = `🔐 **DEVELOPER ONE-TIME KEY GENERATOR** 🔐\n\nC++ অ্যাপে ব্যবহারের জন্য ১-টাইম কী জেনারেট করতে ড্রপডাউন বা বাটনে চাপ দিন।\n*(শুধুমাত্র ডেভেলপারদের জন্য নির্দিষ্ট)*`;

    const embed = new EmbedBuilder()
        .setTitle(fullData.title || "🔑 1TIME KEY GENERATOR PANEL")
        .setDescription(customDescription || defaultDesc)
        .setImage(customImage || COVER_IMAGES.TICKET)
        .setColor("#F1C40F")
        .setFooter({ text: "Developer Portal System", iconURL: client.user.displayAvatarURL() });

    let finalOptions = options;
    if (options.length === 0 || (options.length === 1 && options[0].value === "none")) {
        finalOptions = [
            {
                label: "🔑 Generate 1TIME KEY (Dev Only)",
                description: "C++ অ্যাপের জন্য ১-টাইম কী জেনারেট করুন",
                value: "generate_1time_key"
            }
        ];
    }

    const menu = new StringSelectMenuBuilder()
        .setCustomId("select_key_category")
        .setPlaceholder("👇 কী জেনারেট করতে নিচের ড্রপডাউন সিলেক্ট করুন...")
        .addOptions(finalOptions);

    const buttonRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("btn_generate_1time_key")
            .setLabel("⚡ Generate OneTime Key")
            .setStyle(ButtonStyle.Success)
    );

    return { embeds: [embed], components: [new ActionRowBuilder().addComponents(menu), buttonRow] };
}

async function getDynamicReportPanel() {
    const { options, customDescription, customImage } = await fetchFirebasePanelData("report");
    const defaultDesc = `🚨 **মেম্বার বা স্টাফ রিপোর্ট করার স্থান** 🚨`;

    const embed = new EmbedBuilder()
        .setTitle("🚨 MEMBER & STAFF REPORT CENTER")
        .setDescription(customDescription || defaultDesc)
        .setImage(customImage || COVER_IMAGES.REPORT)
        .setColor("#ED4245")
        .setFooter({ text: "Report Center", iconURL: client.user.displayAvatarURL() });

    const menu = new StringSelectMenuBuilder().setCustomId("select_report_category").setPlaceholder("❓ রিপোর্ট করার কারণ সিলেক্ট করুন...").addOptions(options);
    return { embeds: [embed], components: [new ActionRowBuilder().addComponents(menu)] };
}

async function getDynamicCustomerPanel() {
    const { options, customDescription, customImage } = await fetchFirebasePanelData("customer");
    const defaultDesc = `💬 **কাস্টমার সাপোর্ট অ্যান্ড কুয়েরি** 💬`;

    const embed = new EmbedBuilder()
        .setTitle("💬 VIP CUSTOMER SUPPORT CENTER")
        .setDescription(customDescription || defaultDesc)
        .setImage(customImage || COVER_IMAGES.CUSTOMER)
        .setColor("#57F287")
        .setFooter({ text: "Customer Support", iconURL: client.user.displayAvatarURL() });

    const menu = new StringSelectMenuBuilder().setCustomId("select_customer_category").setPlaceholder("❓ আপনার প্রয়োজনীয় অপশন সিলেক্ট করুন...").addOptions(options);
    return { embeds: [embed], components: [new ActionRowBuilder().addComponents(menu)] };
}

async function getDynamicPaymentPanel() {
    const { options, customDescription, customImage } = await fetchFirebasePanelData("payment");
    const defaultDesc = `💳 **Premium Store & Automatic Payment Gateway** 💳`;

    const readerStatusText = "\n\n🟠 **ONLINE CHECK:** Package ও bKash/Nagad নির্বাচন করার পর Reader-এর live status যাচাই হবে। Online check সফল না হলে payment number দেখানো হবে না।\n🎟️ **Auto Coupon:** default ON — overpayment থেকে তৈরি আপনার active coupon পরের checkout-এ নিজে থেকে প্রযোজ্য হবে। নিচের ON/OFF বোতাম দিয়ে বন্ধ করলে পরের checkout-এ coupon code manually দেওয়া যাবে।";
    let panelDescription = customDescription || defaultDesc;
    // Always hide payment numbers on the shop panel; reveal a provider-specific number only after live check.
    for (const number of Object.values(PAYMENT_NUMBERS).filter(Boolean)) {
        panelDescription = panelDescription.split(number).join("[পেমেন্ট ধাপে দেখানো হবে]");
    }
    panelDescription = panelDescription.replace(/(?:\+?880)?0?1[3-9](?:[\s-]?\d){8}|01[3-9]X{8}/gi, "[পেমেন্ট ধাপে দেখানো হবে]");
    const embed = new EmbedBuilder()
        .setTitle("🛍️ AUTOMATED SHOP & PAYMENT PANELS")
        .setDescription(panelDescription + readerStatusText)
        .setImage(customImage || COVER_IMAGES.PAYMENT)
        .setColor("#3498DB")
        .setFooter({ text: "Automated Payment Bot", iconURL: client.user.displayAvatarURL() });

    const menu = new StringSelectMenuBuilder().setCustomId("select_buy_category").setPlaceholder("🛍️ আপনার কাঙ্ক্ষিত মেম্বারশিপ/সার্ভিস সিলেক্ট করুন...").addOptions(options);
    const autoCouponToggle = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("toggle_auto_coupon").setLabel("🎟️ Auto Coupon ON/OFF (নিজের সেটিং)").setStyle(ButtonStyle.Secondary)
    );
    return { embeds: [embed], components: [new ActionRowBuilder().addComponents(menu), autoCouponToggle] };
}

// Admin Commands
client.on("messageCreate", async (message) => {
    if (message.author.bot || !message.guild || message.guild.id !== ALLOWED_GUILD_ID) return;

    const isServerAdmin = message.member.permissions.has(PermissionFlagsBits.Administrator) || message.member.roles.cache.has(ROLES.ADMIN);

    // Developer/admin access to the one-time-key panel is checked independently of general admin commands.
    if (message.content === "!onetime key" || message.content === "!onetimekey") {
        const canOpenKeyPanel = isServerAdmin || message.member.roles.cache.has(ROLES.DEVELOPER);
        if (canOpenKeyPanel && (ONETIME_KEY_CHANNEL_IDS.includes(message.channelId) || isServerAdmin)) {
            return message.channel.send(await getDynamicOneTimeKeyPanel());
        }
        return;
    }

    if (!isServerAdmin) return;

    if (message.content === "!setup") return message.channel.send({ embeds: [createVerificationEmbed()], components: [verificationRow] });
    if (message.content === "!ticket" && message.channelId === CHANNELS.TICKET_PANEL) return message.channel.send(await getDynamicTicketPanel());
    if (message.content === "!report" && message.channelId === CHANNELS.REPORT_PANEL) return message.channel.send(await getDynamicReportPanel());
    if (message.content === "!customer" && message.channelId === CHANNELS.CUSTOMER_PANEL) return message.channel.send(await getDynamicCustomerPanel());
    if (message.content === "!orderguide" && message.channelId === ORDER_GUIDE_CHANNEL_ID) return message.channel.send(await getDynamicOrderGuidePanel());
    
});

// ================================
// 🔄 REALTIME FIREBASE SYNC LISTENER
// ================================
// ================================
// ⚡ QUEUE SYSTEM FOR SAFE BULK AVATAR & USERNAME UPDATES
// ================================

const updateQueue = new Map(); 
let isProcessingQueue = false;

// 📥 ২০টি ২০টি করে ব্যাচ প্রসেস করার ফাংশন
async function processUpdateQueue() {
    if (isProcessingQueue || updateQueue.size === 0) return;
    isProcessingQueue = true;

    // কিউ থেকে একসাথে প্রথম ২০ জন ইউজারকে বের করা
    const queueEntries = Array.from(updateQueue.entries()).slice(0, 20);

    for (const [userId, data] of queueEntries) {
        try {
            const { newAvatar, newUsername } = data;

            // 1️⃣ users নোড আপডেট (ফায়ারবেস)
            const usersRef = db.ref("users");
            const snapshot = await usersRef.orderByChild("discordId").equalTo(userId).once("value");

            if (snapshot.exists()) {
                const updates = [];
                snapshot.forEach((childSnapshot) => {
                    updates.push(childSnapshot.ref.update({
                        avatarUrl: newAvatar,
                        discordUsername: newUsername,
                        lastUpdated: Date.now()
                    }));
                });
                await Promise.all(updates);
                console.log(`⚡ [Queue Sync] Updated user node for Discord ID: ${userId}`);
            }

            // 2️⃣ keys (1TIME Key) নোড আপডেট (ফায়ারবেস)
            const keysRef = db.ref("keys");
            const keySnap = await keysRef.orderByChild("userId").equalTo(userId).once("value");

            if (keySnap.exists()) {
                const updates = [];
                keySnap.forEach((childSnapshot) => {
                    updates.push(childSnapshot.ref.update({
                        avatarUrl: newAvatar,
                        username: newUsername,
                        lastUpdated: Date.now()
                    }));
                });
                await Promise.all(updates);
                console.log(`⚡ [Queue Sync] Updated keys node for Discord ID: ${userId}`);
            }

        } catch (err) {
            console.error(`❌ Queue Update Error for User ${userId}:`, err);
        } finally {
            // নতুন profile change while processing হলে সেটিকে কিউতে রেখে দিন।
            if (updateQueue.get(userId) === data) updateQueue.delete(userId);
        }
    }

    isProcessingQueue = false;

    // যদি ২০ জনের বেশি ইউজার থাকে, তবে ২ সেকেন্ড বিরতি দিয়ে পরবর্তী ২০ জন প্রসেস করবে
    if (updateQueue.size > 0) {
        setTimeout(processUpdateQueue, 2000); // ২ সেকেন্ড বিরতি
    }
}

// --------------------------------
// ⚡ DISCORD PROFILE CHANGE LISTENERS
// --------------------------------

// ১. মেম্বার সার্ভার প্রোফাইল বা অবতার চেঞ্জ করলে
client.on("guildMemberUpdate", (oldMember, newMember) => {
    const userId = newMember.id;
    const newAvatar = newMember.user.displayAvatarURL({ extension: "png", dynamic: true, size: 512 });
    const newUsername = newMember.user.username;

    // কিউতে তথ্য যোগ করা
    updateQueue.set(userId, { newAvatar, newUsername });
    processUpdateQueue();
});

// ২. মেম্বার গ্লোবাল ডিসকর্ড অবতার চেঞ্জ করলে
client.on("userUpdate", (oldUser, newUser) => {
    const userId = newUser.id;
    const newAvatar = newUser.displayAvatarURL({ extension: "png", dynamic: true, size: 512 });
    const newUsername = newUser.username;

    updateQueue.set(userId, { newAvatar, newUsername });
    processUpdateQueue();
});
function findPanelMessage(messages, expectedCustomId) {
    return messages?.find(message =>
        message.author.id === client.user.id &&
        message.components?.some(row => row.components?.some(component => component.customId === expectedCustomId))
    ) || null;
}

let realtimeListenersRegistered = false;
client.on("ready", async () => {
    console.log(`🤖 Logged in as ${client.user.tag}!`);
    setBotPresence();

    const guild = client.guilds.cache.get(ALLOWED_GUILD_ID);
    if (!guild) {
        console.error("❌ Configured Discord guild not found:", ALLOWED_GUILD_ID);
        return;
    }
    if (realtimeListenersRegistered) return;
    realtimeListenersRegistered = true;

    db.ref("panels/payment").on("value", async () => {
        try {
            const payChan = guild.channels.cache.get(CHANNELS.PAYMENT_PANEL);
            if (!payChan) return;
            const updatedData = await getDynamicPaymentPanel();
            const storedIdSnap = await db.ref("runtime/panels/paymentMessageId").once("value").catch(() => null);
            let botMsg = null;
            const storedId = storedIdSnap?.val();
            if (storedId) botMsg = await payChan.messages.fetch(String(storedId)).catch(() => null);
            if (!botMsg) {
                const messages = await payChan.messages.fetch({ limit: 100 }).catch(() => null);
                botMsg = findPanelMessage(messages, "select_buy_category");
            }
            if (botMsg) await botMsg.edit(updatedData);
            else botMsg = await payChan.send(updatedData);
            await db.ref("runtime/panels/paymentMessageId").set(botMsg.id).catch(err => console.error("Could not save payment panel ID:", err.message));
            console.log("✅ Payment panel synced automatically (no payment setup command required).");
        } catch (err) {
            console.error("❌ Realtime Sync Error on Payment Panel:", err);
        }
    });

    db.ref("panels/onetime_key").on("value", async () => {
        try {
            for (const keyChanId of ONETIME_KEY_CHANNEL_IDS) {
                const keyChan = guild.channels.cache.get(keyChanId);
                if (!keyChan) continue;

                const messages = await keyChan.messages.fetch({ limit: 5 }).catch(() => null);
                const botMsg = findPanelMessage(messages, "select_key_category");

                const updatedData = await getDynamicOneTimeKeyPanel();

                if (botMsg) {
                    await botMsg.edit(updatedData).catch(err => console.error("❌ OneTime Key Panel Edit Fail:", err));
                    console.log(`✅ OneTime Key Panel Auto-Updated from Firebase for channel: ${keyChanId}`);
                }
            }
        } catch (err) {
            console.error("❌ Realtime Sync Error on OneTime Key Panel:", err);
        }
    });

    db.ref("panels").on("value", async (snapshot) => {
        const ticketChan = guild.channels.cache.get(CHANNELS.TICKET_PANEL);
        if (ticketChan) {
            const messages = await ticketChan.messages.fetch({ limit: 5 }).catch(() => null);
            const botMsg = findPanelMessage(messages, "select_product_ticket");
            if (botMsg) {
                const updatedData = await getDynamicTicketPanel();
                await botMsg.edit(updatedData).catch(() => {});
            }
        }

        const reportChan = guild.channels.cache.get(CHANNELS.REPORT_PANEL);
        if (reportChan) {
            const messages = await reportChan.messages.fetch({ limit: 5 }).catch(() => null);
            const botMsg = findPanelMessage(messages, "select_report_category");
            if (botMsg) {
                const updatedData = await getDynamicReportPanel();
                await botMsg.edit(updatedData).catch(() => {});
            }
        }

        const custChan = guild.channels.cache.get(CHANNELS.CUSTOMER_PANEL);
        if (custChan) {
            const messages = await custChan.messages.fetch({ limit: 5 }).catch(() => null);
            const botMsg = findPanelMessage(messages, "select_customer_category");
            if (botMsg) {
                const updatedData = await getDynamicCustomerPanel();
                await botMsg.edit(updatedData).catch(() => {});
            }
        }
    });
});

function setBotPresence() {
    client.user.setPresence({
        activities: [{ name: "Security & Verification", type: ActivityType.Watching }],
        status: "online"
    });
}

function startBot() {
    if (!TOKEN) {
        console.error("❌ TOKEN Environment Variable is missing!");
        return;
    }
    client.login(TOKEN).catch(err => {
        console.error("❌ Discord Login Failed:", err);
    });
}

startBot();
